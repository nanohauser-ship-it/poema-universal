"use client";

import {
  ChangeEvent,
  FormEvent,
  PointerEvent as ReactPointerEvent,
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";

type Voice = {
  id: string;
  name: string;
  place: string;
  language: string;
  excerpt: string;
  fileName: string;
  mimeType: string;
  size: number;
  createdAt: string;
};

type VoiceDraft = {
  key: string;
  file: File;
  name: string;
  place: string;
  language: string;
  excerpt: string;
  status: "ready" | "uploading" | "done" | "error";
  error?: string;
};

type Point3D = { x: number; y: number; z: number; seed: number };

const MAX_SIZE = 40 * 1024 * 1024;
const ACCEPTED_AUDIO = ["audio/mpeg", "audio/wav", "audio/x-wav", "audio/mp4", "audio/aac", "audio/ogg", "audio/webm"];

function hashText(value: string) {
  let hash = 2166136261;
  for (let index = 0; index < value.length; index += 1) {
    hash ^= value.charCodeAt(index);
    hash = Math.imul(hash, 16777619);
  }
  return Math.abs(hash >>> 0);
}

function seededValue(seed: number, index: number) {
  const value = Math.sin(seed * 0.0001 + index * 12.9898) * 43758.5453;
  return value - Math.floor(value);
}

function makeDraftKey(file: File) {
  return `${file.name}-${file.lastModified}-${Date.now()}-${Math.random().toString(36).slice(2)}`;
}

function formatTime(value: number) {
  if (!Number.isFinite(value)) return "0:00";
  const minutes = Math.floor(value / 60);
  const seconds = Math.floor(value % 60).toString().padStart(2, "0");
  return `${minutes}:${seconds}`;
}

function formatSize(bytes: number) {
  if (bytes < 1024 * 1024) return `${Math.max(1, Math.round(bytes / 1024))} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

function buildSpherePoints(total: number): Point3D[] {
  const goldenAngle = Math.PI * (3 - Math.sqrt(5));
  return Array.from({ length: total }, (_, index) => {
    const y = 1 - (index / (total - 1)) * 2;
    const radius = Math.sqrt(1 - y * y);
    const theta = goldenAngle * index;
    return {
      x: Math.cos(theta) * radius,
      y,
      z: Math.sin(theta) * radius,
      seed: seededValue(total, index),
    };
  });
}

function VoiceSphere({
  voices,
  selectedId,
  onSelect,
  energyRef,
}: {
  voices: Voice[];
  selectedId: string | null;
  onSelect: (id: string) => void;
  energyRef: React.MutableRefObject<number>;
}) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const points = useMemo(() => buildSpherePoints(1380), []);
  const rotationRef = useRef({ x: -0.12, y: 0.22 });
  const velocityRef = useRef({ x: 0, y: 0.0018 });
  const dragRef = useRef({ active: false, x: 0, y: 0, moved: 0 });
  const projectedVoicesRef = useRef<Array<{ id: string; x: number; y: number; radius: number; depth: number }>>([]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const context = canvas.getContext("2d");
    if (!context) return;

    let frame = 0;
    let width = 0;
    let height = 0;
    let dpr = 1;

    const resize = () => {
      const rect = canvas.getBoundingClientRect();
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      width = rect.width;
      height = rect.height;
      canvas.width = Math.max(1, Math.round(width * dpr));
      canvas.height = Math.max(1, Math.round(height * dpr));
      context.setTransform(dpr, 0, 0, dpr, 0, 0);
    };

    const observer = new ResizeObserver(resize);
    observer.observe(canvas);
    resize();

    const rotate = (point: Point3D) => {
      const cosY = Math.cos(rotationRef.current.y);
      const sinY = Math.sin(rotationRef.current.y);
      const x1 = point.x * cosY - point.z * sinY;
      const z1 = point.x * sinY + point.z * cosY;
      const cosX = Math.cos(rotationRef.current.x);
      const sinX = Math.sin(rotationRef.current.x);
      return {
        x: x1,
        y: point.y * cosX - z1 * sinX,
        z: point.y * sinX + z1 * cosX,
      };
    };

    const draw = (time: number) => {
      context.clearRect(0, 0, width, height);
      const cx = width / 2;
      const cy = height / 2 + Math.min(24, height * 0.025);
      const sphereRadius = Math.min(width, height) * 0.385;
      const energy = energyRef.current;
      const baseGlow = 0.08 + energy * 0.28;

      if (!dragRef.current.active) {
        rotationRef.current.y += velocityRef.current.y + 0.0011;
        rotationRef.current.x += velocityRef.current.x;
        velocityRef.current.x *= 0.965;
        velocityRef.current.y *= 0.965;
      }

      const halo = context.createRadialGradient(cx, cy, sphereRadius * 0.22, cx, cy, sphereRadius * 1.32);
      halo.addColorStop(0, `rgba(255, 230, 174, ${0.12 + energy * 0.15})`);
      halo.addColorStop(0.58, `rgba(213, 168, 88, ${0.05 + energy * 0.08})`);
      halo.addColorStop(1, "rgba(0,0,0,0)");
      context.fillStyle = halo;
      context.beginPath();
      context.arc(cx, cy, sphereRadius * 1.35, 0, Math.PI * 2);
      context.fill();

      const sortedPoints = points
        .map((point) => ({ ...rotate(point), seed: point.seed }))
        .sort((a, b) => a.z - b.z);

      for (const point of sortedPoints) {
        const perspective = 0.83 + (point.z + 1) * 0.105;
        const px = cx + point.x * sphereRadius * perspective;
        const py = cy + point.y * sphereRadius * perspective;
        const front = (point.z + 1) / 2;
        const pulse = Math.max(0, Math.sin(time * 0.0014 + point.seed * 22));
        const orbitLight = Math.max(0, Math.sin(time * 0.00055 + point.seed * 45 + point.y * 6));
        const alpha = 0.12 + front * 0.64 + pulse * baseGlow + orbitLight * 0.11;
        const size = 0.35 + front * 1.18 + (pulse + energy) * 0.5;

        context.fillStyle = `rgba(255, ${Math.round(219 + front * 24)}, ${Math.round(152 + front * 70)}, ${Math.min(1, alpha)})`;
        context.beginPath();
        context.arc(px, py, size, 0, Math.PI * 2);
        context.fill();
      }

      context.save();
      context.globalCompositeOperation = "screen";
      for (let ribbon = 0; ribbon < 7; ribbon += 1) {
        context.beginPath();
        const phase = time * (0.00016 + ribbon * 0.000008) + ribbon * 0.82;
        for (let step = 0; step <= 180; step += 1) {
          const longitude = (step / 180) * Math.PI * 2 + phase;
          const latitude = Math.sin(longitude * (1.3 + ribbon * 0.07) + ribbon) * (0.18 + ribbon * 0.022);
          const local: Point3D = {
            x: Math.cos(longitude) * Math.cos(latitude),
            y: Math.sin(latitude),
            z: Math.sin(longitude) * Math.cos(latitude),
            seed: 0,
          };
          const point = rotate(local);
          if (point.z < -0.48) continue;
          const perspective = 0.83 + (point.z + 1) * 0.105;
          const px = cx + point.x * sphereRadius * perspective;
          const py = cy + point.y * sphereRadius * perspective;
          if (step === 0) context.moveTo(px, py);
          else context.lineTo(px, py);
        }
        context.strokeStyle = `rgba(255, 226, 174, ${0.12 + ribbon * 0.018 + energy * 0.17})`;
        context.lineWidth = 0.55 + energy * 0.85;
        context.stroke();
      }
      context.restore();

      const projectedVoices: Array<{ id: string; x: number; y: number; radius: number; depth: number }> = [];
      voices.forEach((voice, index) => {
        const seed = hashText(voice.id);
        const sphereIndex = seed % points.length;
        const point = rotate(points[sphereIndex]);
        const perspective = 0.83 + (point.z + 1) * 0.105;
        const px = cx + point.x * sphereRadius * perspective;
        const py = cy + point.y * sphereRadius * perspective;
        const isSelected = voice.id === selectedId;
        const glow = 5.5 + ((Math.sin(time * 0.003 + index) + 1) / 2) * 4 + energy * 9;
        const opacity = 0.32 + ((point.z + 1) / 2) * 0.68;

        context.shadowColor = isSelected ? "rgba(255,245,208,.98)" : "rgba(224,174,90,.88)";
        context.shadowBlur = glow;
        context.fillStyle = isSelected ? "#fff6dc" : `rgba(239,193,110,${opacity})`;
        context.beginPath();
        context.arc(px, py, isSelected ? 5.2 : 3.2, 0, Math.PI * 2);
        context.fill();
        context.shadowBlur = 0;
        projectedVoices.push({ id: voice.id, x: px, y: py, radius: isSelected ? 14 : 11, depth: point.z });
      });
      projectedVoicesRef.current = projectedVoices.sort((a, b) => b.depth - a.depth);

      const sweepAngle = time * 0.00028;
      const sweepX = cx + Math.cos(sweepAngle) * sphereRadius * 0.88;
      const sweepY = cy + Math.sin(sweepAngle * 1.36) * sphereRadius * 0.42;
      const sweep = context.createRadialGradient(sweepX, sweepY, 0, sweepX, sweepY, 34 + energy * 28);
      sweep.addColorStop(0, `rgba(255,245,206,${0.75 + energy * 0.2})`);
      sweep.addColorStop(0.18, `rgba(244,190,91,${0.32 + energy * 0.22})`);
      sweep.addColorStop(1, "rgba(244,190,91,0)");
      context.fillStyle = sweep;
      context.beginPath();
      context.arc(sweepX, sweepY, 36 + energy * 28, 0, Math.PI * 2);
      context.fill();

      frame = requestAnimationFrame(draw);
    };

    frame = requestAnimationFrame(draw);
    return () => {
      cancelAnimationFrame(frame);
      observer.disconnect();
    };
  }, [energyRef, onSelect, points, selectedId, voices]);

  const onPointerDown = (event: ReactPointerEvent<HTMLCanvasElement>) => {
    event.currentTarget.setPointerCapture(event.pointerId);
    dragRef.current = { active: true, x: event.clientX, y: event.clientY, moved: 0 };
    velocityRef.current = { x: 0, y: 0 };
  };

  const onPointerMove = (event: ReactPointerEvent<HTMLCanvasElement>) => {
    if (!dragRef.current.active) return;
    const dx = event.clientX - dragRef.current.x;
    const dy = event.clientY - dragRef.current.y;
    dragRef.current.x = event.clientX;
    dragRef.current.y = event.clientY;
    dragRef.current.moved += Math.abs(dx) + Math.abs(dy);
    rotationRef.current.y += dx * 0.006;
    rotationRef.current.x = Math.max(-1.15, Math.min(1.15, rotationRef.current.x + dy * 0.004));
    velocityRef.current = { x: dy * 0.00024, y: dx * 0.00032 };
  };

  const onPointerUp = (event: ReactPointerEvent<HTMLCanvasElement>) => {
    if (dragRef.current.moved < 8) {
      const rect = event.currentTarget.getBoundingClientRect();
      const x = event.clientX - rect.left;
      const y = event.clientY - rect.top;
      const hit = projectedVoicesRef.current.find((voice) => Math.hypot(voice.x - x, voice.y - y) <= voice.radius);
      if (hit) onSelect(hit.id);
    }
    dragRef.current.active = false;
  };

  return (
    <canvas
      ref={canvasRef}
      className="voice-sphere"
      aria-label="Esfera de voces. Arrastra para girarla y pulsa una luz para seleccionar una voz."
      onPointerDown={onPointerDown}
      onPointerMove={onPointerMove}
      onPointerUp={onPointerUp}
      onPointerCancel={() => { dragRef.current.active = false; }}
    />
  );
}

function Waveform({ seed, active }: { seed: string; active: boolean }) {
  const bars = useMemo(() => {
    const hash = hashText(seed || "voice");
    return Array.from({ length: 42 }, (_, index) => 12 + seededValue(hash, index) * 62);
  }, [seed]);

  return (
    <div className={`waveform ${active ? "is-active" : ""}`} aria-hidden="true">
      {bars.map((height, index) => (
        <span key={index} style={{ height: `${height}%`, animationDelay: `${index * -34}ms` }} />
      ))}
    </div>
  );
}

function UploadStudio({
  open,
  onClose,
  onUploaded,
}: {
  open: boolean;
  onClose: () => void;
  onUploaded: () => Promise<void>;
}) {
  const inputRef = useRef<HTMLInputElement | null>(null);
  const [drafts, setDrafts] = useState<VoiceDraft[]>([]);
  const [isDragging, setIsDragging] = useState(false);
  const [isUploading, setIsUploading] = useState(false);

  const addFiles = (incoming: File[]) => {
    const audioFiles = incoming.filter((file) => ACCEPTED_AUDIO.includes(file.type) || /\.(mp3|wav|m4a|aac|ogg|webm)$/i.test(file.name));
    const next = audioFiles.map((file) => ({
      key: makeDraftKey(file),
      file,
      name: file.name.replace(/\.[^.]+$/, "").replace(/[-_]+/g, " "),
      place: "",
      language: "",
      excerpt: "",
      status: file.size <= MAX_SIZE ? "ready" as const : "error" as const,
      error: file.size <= MAX_SIZE ? undefined : "El archivo supera los 40 MB",
    }));
    setDrafts((current) => [...current, ...next]);
  };

  const onFiles = (event: ChangeEvent<HTMLInputElement>) => {
    addFiles(Array.from(event.target.files ?? []));
    event.target.value = "";
  };

  const updateDraft = (key: string, field: "name" | "place" | "language" | "excerpt", value: string) => {
    setDrafts((current) => current.map((draft) => draft.key === key ? { ...draft, [field]: value } : draft));
  };

  const upload = async (event: FormEvent) => {
    event.preventDefault();
    const pending = drafts.filter((draft) => draft.status === "ready");
    if (!pending.length) return;
    setIsUploading(true);

    for (const draft of pending) {
      setDrafts((current) => current.map((item) => item.key === draft.key ? { ...item, status: "uploading" } : item));
      const payload = new FormData();
      payload.set("audio", draft.file);
      payload.set("name", draft.name.trim() || "Voz sin nombre");
      payload.set("place", draft.place.trim());
      payload.set("language", draft.language.trim());
      payload.set("excerpt", draft.excerpt.trim());

      try {
        const response = await fetch("/api/voices", { method: "POST", body: payload });
        const result = await response.json() as { error?: string };
        if (!response.ok) throw new Error(result.error || "No se pudo guardar la voz");
        setDrafts((current) => current.map((item) => item.key === draft.key ? { ...item, status: "done" } : item));
      } catch (error) {
        setDrafts((current) => current.map((item) => item.key === draft.key ? {
          ...item,
          status: "error",
          error: error instanceof Error ? error.message : "Error al guardar",
        } : item));
      }
    }

    await onUploaded();
    setIsUploading(false);
  };

  if (!open) return null;

  const remaining = drafts.some((draft) => draft.status === "ready");

  return (
    <div className="studio-backdrop" role="dialog" aria-modal="true" aria-labelledby="studio-title">
      <section className="upload-studio">
        <header className="studio-header">
          <div>
            <p className="eyebrow">ARCHIVO SONORO</p>
            <h2 id="studio-title">Añadir voces a la Tierra</h2>
            <p>Selecciona varias grabaciones y completa la identidad de cada voz.</p>
          </div>
          <button type="button" className="close-button" onClick={onClose} aria-label="Cerrar">×</button>
        </header>

        <form onSubmit={upload}>
          <div
            className={`drop-zone ${isDragging ? "is-dragging" : ""}`}
            onDragOver={(event) => { event.preventDefault(); setIsDragging(true); }}
            onDragLeave={() => setIsDragging(false)}
            onDrop={(event) => {
              event.preventDefault();
              setIsDragging(false);
              addFiles(Array.from(event.dataTransfer.files));
            }}
          >
            <input ref={inputRef} type="file" multiple accept="audio/*,.mp3,.wav,.m4a,.aac,.ogg,.webm" onChange={onFiles} hidden />
            <span className="drop-icon" aria-hidden="true">＋</span>
            <strong>Arrastra aquí tus audios</strong>
            <span>o selecciona varios archivos MP3, WAV, M4A, AAC, OGG o WebM</span>
            <button type="button" className="secondary-button" onClick={() => inputRef.current?.click()}>Elegir audios</button>
          </div>

          <div className="draft-list">
            {drafts.map((draft, index) => (
              <article className={`draft-card status-${draft.status}`} key={draft.key}>
                <div className="draft-number">{String(index + 1).padStart(2, "0")}</div>
                <div className="draft-fields">
                  <div className="file-line">
                    <strong>{draft.file.name}</strong>
                    <span>{formatSize(draft.file.size)}</span>
                  </div>
                  <div className="field-grid">
                    <label>Nombre de la voz<input value={draft.name} onChange={(event) => updateDraft(draft.key, "name", event.target.value)} /></label>
                    <label>Lugar<input value={draft.place} onChange={(event) => updateDraft(draft.key, "place", event.target.value)} placeholder="Dakar, Senegal" /></label>
                    <label>Idioma<input value={draft.language} onChange={(event) => updateDraft(draft.key, "language", event.target.value)} placeholder="Wolof" /></label>
                    <label className="excerpt-field">Verso o fragmento<textarea value={draft.excerpt} onChange={(event) => updateDraft(draft.key, "excerpt", event.target.value)} placeholder="La frase que acompañará a esta voz…" rows={2} /></label>
                  </div>
                  {draft.status === "uploading" && <p className="status-line">Guardando la voz…</p>}
                  {draft.status === "done" && <p className="status-line success">Voz incorporada a la esfera</p>}
                  {draft.error && <p className="status-line error">{draft.error}</p>}
                </div>
                <button type="button" className="remove-draft" onClick={() => setDrafts((current) => current.filter((item) => item.key !== draft.key))} aria-label={`Quitar ${draft.file.name}`}>×</button>
              </article>
            ))}
          </div>

          <footer className="studio-footer">
            <p>{drafts.length ? `${drafts.length} ${drafts.length === 1 ? "grabación preparada" : "grabaciones preparadas"}` : "Puedes incorporar tantas voces como necesites"}</p>
            <button className="primary-button" type="submit" disabled={!remaining || isUploading}>
              {isUploading ? "INCORPORANDO VOCES…" : "INCORPORAR A LA ESFERA"}
            </button>
          </footer>
        </form>
      </section>
    </div>
  );
}

export default function CoroExperience() {
  const [voices, setVoices] = useState<Voice[]>([]);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [playingId, setPlayingId] = useState<string | null>(null);
  const [studioOpen, setStudioOpen] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [progress, setProgress] = useState({ current: 0, duration: 0 });
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const sourceRef = useRef<MediaElementAudioSourceNode | null>(null);
  const energyRef = useRef(0);
  const animationRef = useRef(0);

  const selected = voices.find((voice) => voice.id === selectedId) ?? voices[0] ?? null;

  const loadVoices = useCallback(async () => {
    try {
      const response = await fetch("/api/voices", { cache: "no-store" });
      const result = await response.json() as { voices?: Voice[]; error?: string };
      if (!response.ok) throw new Error(result.error || "No se pudieron leer las voces");
      const nextVoices = result.voices ?? [];
      setVoices(nextVoices);
      setSelectedId((current) => current && nextVoices.some((voice) => voice.id === current) ? current : nextVoices[0]?.id ?? null);
      setError(null);
    } catch (loadError) {
      setError(loadError instanceof Error ? loadError.message : "No se pudo abrir el archivo sonoro");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void loadVoices();
  }, [loadVoices]);

  useEffect(() => {
    const audio = new Audio();
    audio.preload = "metadata";
    audioRef.current = audio;

    const updateProgress = () => setProgress({ current: audio.currentTime || 0, duration: audio.duration || 0 });
    const onEnded = () => {
      setPlayingId(null);
      energyRef.current = 0;
      setProgress((current) => ({ ...current, current: 0 }));
    };
    audio.addEventListener("timeupdate", updateProgress);
    audio.addEventListener("loadedmetadata", updateProgress);
    audio.addEventListener("ended", onEnded);

    const updateEnergy = () => {
      if (analyserRef.current) {
        const data = new Uint8Array(analyserRef.current.frequencyBinCount);
        analyserRef.current.getByteFrequencyData(data);
        const sampleCount = Math.max(1, Math.min(48, data.length));
        let sum = 0;
        for (let index = 0; index < sampleCount; index += 1) sum += data[index];
        const target = sum / sampleCount / 255;
        energyRef.current += (target - energyRef.current) * 0.18;
      } else {
        energyRef.current *= 0.9;
      }
      animationRef.current = requestAnimationFrame(updateEnergy);
    };
    animationRef.current = requestAnimationFrame(updateEnergy);

    return () => {
      cancelAnimationFrame(animationRef.current);
      audio.pause();
      audio.removeEventListener("timeupdate", updateProgress);
      audio.removeEventListener("loadedmetadata", updateProgress);
      audio.removeEventListener("ended", onEnded);
      void audioContextRef.current?.close();
    };
  }, []);

  const ensureAnalyser = () => {
    const audio = audioRef.current;
    if (!audio || sourceRef.current) return;
    const AudioContextConstructor = window.AudioContext || (window as typeof window & { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!AudioContextConstructor) return;
    const context = new AudioContextConstructor();
    const analyser = context.createAnalyser();
    analyser.fftSize = 256;
    analyser.smoothingTimeConstant = 0.8;
    const source = context.createMediaElementSource(audio);
    source.connect(analyser);
    analyser.connect(context.destination);
    audioContextRef.current = context;
    analyserRef.current = analyser;
    sourceRef.current = source;
  };

  const toggleVoice = async (voice: Voice) => {
    const audio = audioRef.current;
    if (!audio) return;
    setSelectedId(voice.id);
    ensureAnalyser();
    if (audioContextRef.current?.state === "suspended") await audioContextRef.current.resume();

    if (playingId === voice.id && !audio.paused) {
      audio.pause();
      setPlayingId(null);
      return;
    }

    if (!audio.src.includes(`id=${encodeURIComponent(voice.id)}`)) {
      audio.src = `/api/audio?id=${encodeURIComponent(voice.id)}`;
      setProgress({ current: 0, duration: 0 });
    }
    try {
      await audio.play();
      setPlayingId(voice.id);
    } catch {
      setError("El navegador no pudo reproducir esta grabación.");
    }
  };

  const playHumanity = async () => {
    if (!voices.length) {
      setStudioOpen(true);
      return;
    }
    const currentIndex = selected ? voices.findIndex((voice) => voice.id === selected.id) : -1;
    const next = playingId ? voices[(currentIndex + 1) % voices.length] : selected ?? voices[0];
    await toggleVoice(next);
  };

  const seek = (event: ChangeEvent<HTMLInputElement>) => {
    const audio = audioRef.current;
    if (!audio) return;
    audio.currentTime = Number(event.target.value);
    setProgress((current) => ({ ...current, current: audio.currentTime }));
  };

  const deleteVoice = async (voice: Voice) => {
    if (!window.confirm(`¿Retirar la voz de ${voice.name} del archivo?`)) return;
    if (playingId === voice.id) {
      audioRef.current?.pause();
      setPlayingId(null);
    }
    const response = await fetch(`/api/voices?id=${encodeURIComponent(voice.id)}`, { method: "DELETE" });
    if (!response.ok) {
      const result = await response.json() as { error?: string };
      setError(result.error || "No se pudo retirar la voz");
      return;
    }
    await loadVoices();
  };

  return (
    <main className="coro-room">
      <div className="architectural-light" aria-hidden="true" />
      <div className="ceiling-rings" aria-hidden="true" />
      <div className="distant-archive left" aria-hidden="true" />
      <div className="distant-archive right" aria-hidden="true" />
      <div className="floor-reflection" aria-hidden="true" />

      <header className="topbar">
        <a href="/" className="brand">POEMA UNIVERSAL</a>
        <div className="room-label"><span />SALA INDEPENDIENTE<span /></div>
        <button className="add-top" type="button" onClick={() => setStudioOpen(true)}>＋ AÑADIR VOCES</button>
      </header>

      <section className="title-block">
        <p>ARCHIVO SONORO UNIVERSAL</p>
        <h1>EL CORO DE LA TIERRA</h1>
        <span>Un archivo vivo de voces humanas</span>
      </section>

      <div className="sphere-stage">
        <VoiceSphere voices={voices} selectedId={selected?.id ?? null} onSelect={setSelectedId} energyRef={energyRef} />
        <div className="sphere-shadow" aria-hidden="true" />
        <div className="drag-hint" aria-hidden="true"><span>↔</span> ARRASTRA PARA GIRAR</div>
      </div>

      <aside className={`voice-card ${selected ? "has-voice" : "is-empty"}`}>
        {loading ? (
          <div className="empty-voice"><span className="voice-index">ABRIENDO ARCHIVO</span><p>Escuchando el silencio de la sala…</p></div>
        ) : selected ? (
          <>
            <div className="voice-card-head">
              <span className="voice-index">VOZ {String(voices.findIndex((voice) => voice.id === selected.id) + 1).padStart(3, "0")}</span>
              <button className="play-button" type="button" onClick={() => void toggleVoice(selected)} aria-label={playingId === selected.id ? "Pausar voz" : "Escuchar voz"}>
                {playingId === selected.id ? <span className="pause-icon" /> : <span className="play-icon" />}
              </button>
            </div>
            <div className="gold-rule" />
            <h2>{selected.name}</h2>
            <p className="origin">{[selected.place, selected.language].filter(Boolean).join(" · ") || "Procedencia por registrar"}</p>
            <Waveform seed={selected.id} active={playingId === selected.id} />
            <div className="audio-progress">
              <span>{formatTime(progress.current)}</span>
              <input type="range" min="0" max={progress.duration || 1} step="0.01" value={Math.min(progress.current, progress.duration || 1)} onChange={seek} aria-label="Posición del audio" />
              <span>{formatTime(progress.duration)}</span>
            </div>
            {selected.excerpt && <blockquote>“{selected.excerpt}”</blockquote>}
            <div className="card-actions">
              <button type="button" onClick={() => setStudioOpen(true)}>＋ Añadir más</button>
              <button type="button" className="remove-voice" onClick={() => void deleteVoice(selected)}>Retirar</button>
            </div>
          </>
        ) : (
          <div className="empty-voice">
            <span className="voice-index">LA PRIMERA VOZ</span>
            <h2>La Tierra está esperando</h2>
            <p>Incorpora una o varias grabaciones para que la esfera comience a guardar la memoria humana.</p>
            <button type="button" className="secondary-button" onClick={() => setStudioOpen(true)}>＋ AÑADIR VOCES</button>
          </div>
        )}
      </aside>

      <div className="voice-count"><strong>{voices.length}</strong><span>{voices.length === 1 ? "VOZ CONSERVADA" : "VOCES CONSERVADAS"}</span></div>

      <button type="button" className="humanity-button" onClick={() => void playHumanity()}>
        <span className="button-light" />
        {voices.length ? "ESCUCHAR A LA HUMANIDAD" : "DARLE UNA VOZ A LA TIERRA"}
      </button>

      {error && <div className="error-toast" role="alert">{error}<button onClick={() => setError(null)} aria-label="Cerrar aviso">×</button></div>}

      <UploadStudio open={studioOpen} onClose={() => setStudioOpen(false)} onUploaded={loadVoices} />
    </main>
  );
}
