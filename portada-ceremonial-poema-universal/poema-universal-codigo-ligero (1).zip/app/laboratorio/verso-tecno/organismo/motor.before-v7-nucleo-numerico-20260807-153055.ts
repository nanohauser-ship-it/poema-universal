export type Habitat =
  | "deriva"
  | "pulso"
  | "fractura"
  | "espectral"
  | "maquina"
  | "memoria";

export type Etapa =
  | "embrion"
  | "germinacion"
  | "formacion"
  | "cuerpo"
  | "mutacion"
  | "madurez"
  | "latencia";

export type EntradaVital = {
  id: string;
  dia: number;
  fecha: string;
  titulo: string;
  texto: string;
  habitat: Habitat;
};

export type Organismo = {
  version: 4;
  id: string;
  codigo: string;
  nombre: string;
  poema: string;
  nacimiento: string;
  ultimaEvolucion: string;
  ultimaInteraccion: string;
  edad: number;
  etapa: Etapa;
  semilla: number;
  reliquia: string;
  bpmBase: number;
  tonalidad: string;
  habitats: Record<Habitat, number>;
  energia: number;
  estabilidad: number;
  memoriaVital: number;
  complejidad: number;
  notas: string[];
  diario: EntradaVital[];
  injertos: string[];
};

export const HABITATS: Habitat[] = [
  "deriva",
  "pulso",
  "fractura",
  "espectral",
  "maquina",
  "memoria",
];

export const CICLOS_COMPOSICION = 56;

const STOP = new Set([
  "a", "al", "ante", "bajo", "como", "con", "de", "del", "desde", "el",
  "ella", "en", "entre", "era", "es", "esta", "fue", "ha", "hasta", "la",
  "las", "lo", "los", "más", "mas", "me", "mi", "muy", "no", "nos", "o",
  "para", "pero", "por", "que", "se", "sin", "sobre", "su", "sus", "te",
  "tu", "un", "una", "y", "ya",
]);

const VOCABULARIO: Record<Habitat, string[]> = {
  deriva: [
    "agua", "mar", "rio", "lluvia", "aire", "viento", "nube", "niebla",
    "sueño", "sueno", "flotar", "lejos", "noche", "lento",
  ],
  pulso: [
    "cuerpo", "piel", "sangre", "corazon", "latido", "hambre", "carne",
    "mano", "pie", "boca", "deseo", "golpe", "ritmo",
  ],
  fractura: [
    "roto", "corte", "caer", "grito", "herida", "fragmento", "ruina",
    "nunca", "partir", "fractura", "error", "vacio",
  ],
  espectral: [
    "sombra", "fantasma", "muerte", "muerto", "silencio", "ausencia",
    "nadie", "desaparecer", "olvido", "eco", "voz", "alma",
  ],
  maquina: [
    "maquina", "motor", "hierro", "metal", "codigo", "cable", "ciudad",
    "fabrica", "tren", "reloj", "ruido",
  ],
  memoria: [
    "memoria", "recuerdo", "nombre", "ayer", "antes", "infancia", "madre",
    "padre", "fotografia", "cuaderno", "historia", "volver", "regresar",
  ],
};

const ESCALAS = [
  ["c2", "eb2", "g2", "bb2", "d3", "f3"],
  ["d2", "f2", "a2", "c3", "e3", "g3"],
  ["eb2", "gb2", "bb2", "db3", "f3", "ab3"],
  ["f2", "ab2", "c3", "eb3", "g3", "bb3"],
];

const TONALIDADES = ["C menor", "D dórico", "Eb menor", "F lidio"];

const MUTACIONES: Record<Habitat, string[]> = {
  deriva: [
    "Una corriente desplazó la armonía",
    "La membrana comenzó a flotar",
    "El espacio se volvió más profundo",
  ],
  pulso: [
    "Apareció un nuevo latido",
    "El subgrave adquirió cuerpo",
    "La respiración encontró una cadencia",
  ],
  fractura: [
    "La métrica desarrolló una cicatriz",
    "Un motivo se partió en fragmentos",
    "El silencio cortó la secuencia",
  ],
  espectral: [
    "La palabra reliquia dejó una sombra",
    "Una presencia atravesó el núcleo",
    "Nació una cola espectral",
  ],
  maquina: [
    "Apareció una estructura metálica",
    "El reloj interno ganó precisión",
    "Una secuencia mecánica ocupó el borde",
  ],
  memoria: [
    "Regresó una forma del primer día",
    "El organismo recordó una nota perdida",
    "Un eco antiguo volvió transformado",
  ],
};

function normalizar(texto: string): string {
  return texto
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "");
}

export function hashTexto(texto: string): number {
  let resultado = 2166136261;
  for (let i = 0; i < texto.length; i += 1) {
    resultado ^= texto.charCodeAt(i);
    resultado = Math.imul(resultado, 16777619);
  }
  return Math.abs(resultado >>> 0);
}

function azar(semilla: number, indice: number): number {
  const valor = Math.sin(semilla * 0.000017 + indice * 71.923) * 43758.5453;
  return valor - Math.floor(valor);
}

function limitar(valor: number, min = 0, max = 100): number {
  return Math.max(min, Math.min(max, Math.round(valor)));
}

function palabras(texto: string): string[] {
  return (
    texto.match(/[A-Za-zÁÉÍÓÚÜÑáéíóúüñ]+(?:['’-][A-Za-zÁÉÍÓÚÜÑáéíóúüñ]+)*/g) ??
    []
  );
}

function relevantes(texto: string): string[] {
  return palabras(texto).filter((palabra) => {
    const limpia = normalizar(palabra);
    return limpia.length > 2 && !STOP.has(limpia);
  });
}

function reliquiaDe(texto: string): string {
  const lista = relevantes(texto);
  if (!lista.length) return "silencio";

  const frecuencia = new Map<string, { original: string; n: number }>();
  lista.forEach((palabra) => {
    const clave = normalizar(palabra);
    const anterior = frecuencia.get(clave);
    frecuencia.set(clave, {
      original: anterior?.original ?? palabra,
      n: (anterior?.n ?? 0) + 1,
    });
  });

  return [...frecuencia.values()].sort(
    (a, b) =>
      b.n * 10 +
      b.original.length -
      (a.n * 10 + a.original.length),
  )[0].original;
}

function etapaPorEdad(edad: number): Etapa {
  if (edad <= 0) return "embrion";
  if (edad <= 3) return "germinacion";
  if (edad <= 7) return "formacion";
  if (edad <= 14) return "cuerpo";
  if (edad <= 30) return "mutacion";
  return "madurez";
}

function fechaHoy(): string {
  return new Date().toISOString().slice(0, 10);
}

function diasEntre(desde: string, hasta: string): number {
  const a = new Date(`${desde}T00:00:00`).getTime();
  const b = new Date(`${hasta}T00:00:00`).getTime();
  return Math.max(0, Math.floor((b - a) / 86400000));
}

export function analizarPoema(texto: string) {
  const lista = relevantes(texto);
  const semilla = hashTexto(texto || "silencio");
  const signos = (texto.match(/[,.…;:!?—-]/g) ?? []).length;
  const lineas = Math.max(
    1,
    texto.split(/\n+/).map((x) => x.trim()).filter(Boolean).length,
  );

  const habitats = {} as Record<Habitat, number>;

  HABITATS.forEach((habitat, indice) => {
    const diccionario = new Set(VOCABULARIO[habitat].map(normalizar));
    const coincidencias = lista.filter((p) =>
      diccionario.has(normalizar(p)),
    ).length;

    habitats[habitat] = limitar(
      18 +
        coincidencias * 14 +
        azar(semilla, indice + 1) * 18 +
        (habitat === "fractura" ? signos * 2 : 0) +
        (habitat === "deriva" ? lineas * 2 : 0),
      7,
      96,
    );
  });

  const escala = ESCALAS[semilla % ESCALAS.length];
  const notas = [...new Set(lista.map((p) => escala[hashTexto(p) % escala.length]))]
    .slice(0, 7);

  return {
    semilla,
    reliquia: reliquiaDe(texto),
    habitats,
    notas: notas.length ? notas : escala.slice(0, 4),
    bpmBase: limitar(
      65 + habitats.pulso * 0.55 + habitats.maquina * 0.16 -
        habitats.deriva * 0.18,
      45,
      145,
    ),
    tonalidad: TONALIDADES[semilla % TONALIDADES.length],
  };
}

export function incubar(nombre: string, poema: string): Organismo {
  const fecha = fechaHoy();
  const analisis = analizarPoema(poema);
  const semilla = hashTexto(`${poema}|${nombre}|${Date.now()}`);
  const codigo = `OE-${String(semilla % 100000).padStart(5, "0")}`;

  return {
    version: 4,
    id: `${codigo}-${Date.now()}`,
    codigo,
    nombre: nombre.trim() || analisis.reliquia,
    poema,
    nacimiento: fecha,
    ultimaEvolucion: fecha,
    ultimaInteraccion: fecha,
    edad: 0,
    etapa: "embrion",
    semilla,
    reliquia: analisis.reliquia,
    bpmBase: analisis.bpmBase,
    tonalidad: analisis.tonalidad,
    habitats: analisis.habitats,
    energia: limitar(28 + analisis.habitats.pulso * 0.25),
    estabilidad: limitar(
      52 + analisis.habitats.memoria * 0.15 -
        analisis.habitats.fractura * 0.12,
    ),
    memoriaVital: limitar(18 + analisis.habitats.memoria * 0.35),
    complejidad: 14,
    notas: analisis.notas,
    injertos: [],
    diario: [
      {
        id: `nacimiento-${semilla}`,
        dia: 0,
        fecha,
        titulo: "El poema fue incubado",
        texto:
          `${codigo} nació alrededor de la palabra «${analisis.reliquia}». ` +
          "Todavía no posee una forma musical cerrada.",
        habitat: "memoria",
      },
    ],
  };
}

function habitatDominante(
  organismo: Organismo,
  dia: number,
): Habitat {
  return HABITATS.map((habitat, indice) => ({
    habitat,
    valor:
      organismo.habitats[habitat] +
      azar(organismo.semilla, dia * 13 + indice) * 42,
  })).sort((a, b) => b.valor - a.valor)[0].habitat;
}

function evolucionarDia(
  organismo: Organismo,
  dia: number,
  fecha: string,
): Organismo {
  const habitat = habitatDominante(organismo, dia);
  const opciones = MUTACIONES[habitat];
  const titulo =
    opciones[
      Math.floor(azar(organismo.semilla, dia * 29) * opciones.length) %
        opciones.length
    ];

  const entrada: EntradaVital = {
    id: `dia-${dia}-${organismo.semilla}`,
    dia,
    fecha,
    titulo,
    habitat,
    texto:
      `${titulo}. El hábitat ${habitat} modificó su densidad, ` +
      "su memoria o su respiración electrónica.",
  };

  return {
    ...organismo,
    edad: dia,
    etapa: etapaPorEdad(dia),
    ultimaEvolucion: fecha,
    energia: limitar(
      organismo.energia + (habitat === "pulso" ? 5 : 2) -
        (habitat === "deriva" ? 1 : 0),
    ),
    estabilidad: limitar(
      organismo.estabilidad + (habitat === "memoria" ? 3 : 0) -
        (habitat === "fractura" ? 4 : 1),
    ),
    memoriaVital: limitar(
      organismo.memoriaVital + (habitat === "memoria" ? 6 : 2),
    ),
    complejidad: limitar(organismo.complejidad + 3),
    diario: [...organismo.diario, entrada].slice(-160),
  };
}

export function evolucionarHastaHoy(organismo: Organismo): {
  organismo: Organismo;
  ciclos: number;
} {
  const hoy = fechaHoy();
  const ciclos = diasEntre(organismo.ultimaEvolucion, hoy);
  let actual = organismo;

  for (let i = 1; i <= ciclos; i += 1) {
    const fecha = new Date(`${organismo.ultimaEvolucion}T12:00:00`);
    fecha.setDate(fecha.getDate() + i);
    actual = evolucionarDia(
      actual,
      organismo.edad + i,
      fecha.toISOString().slice(0, 10),
    );
  }

  if (diasEntre(actual.ultimaInteraccion, hoy) >= 14) {
    actual = {
      ...actual,
      etapa: "latencia",
      energia: limitar(actual.energia - 14),
    };
  }

  return { organismo: actual, ciclos };
}

export function mutarAhora(organismo: Organismo): Organismo {
  const indice = organismo.diario.length + 700;
  const habitat = habitatDominante(organismo, indice);
  const opciones = MUTACIONES[habitat];
  const titulo =
    opciones[Math.floor(azar(organismo.semilla, indice) * opciones.length)];

  return {
    ...organismo,
    ultimaInteraccion: fechaHoy(),
    complejidad: limitar(organismo.complejidad + 3),
    estabilidad: limitar(
      organismo.estabilidad - (habitat === "fractura" ? 4 : 1),
    ),
    diario: [
      ...organismo.diario,
      {
        id: `lab-${indice}-${Date.now()}`,
        dia: organismo.edad,
        fecha: fechaHoy(),
        titulo,
        habitat,
        texto:
          `${titulo}. Fue una mutación inducida y no alteró su edad cronológica.`,
      },
    ].slice(-160),
  };
}

export function despertar(organismo: Organismo): Organismo {
  return {
    ...organismo,
    etapa: etapaPorEdad(organismo.edad),
    energia: limitar(organismo.energia + 12),
    ultimaInteraccion: fechaHoy(),
  };
}

export function injertar(
  organismo: Organismo,
  verso: string,
): Organismo {
  const limpio = verso.trim();
  if (!limpio) return organismo;

  const habitat = HABITATS[hashTexto(limpio) % HABITATS.length];

  return {
    ...organismo,
    ultimaInteraccion: fechaHoy(),
    energia: limitar(organismo.energia + 5),
    complejidad: limitar(organismo.complejidad + 5),
    memoriaVital: limitar(organismo.memoriaVital + 3),
    injertos: [...organismo.injertos, limpio].slice(-50),
    diario: [
      ...organismo.diario,
      {
        id: `injerto-${Date.now()}`,
        dia: organismo.edad,
        fecha: fechaHoy(),
        titulo: "El organismo recibió un injerto",
        habitat,
        texto:
          `«${limpio.slice(0, 120)}» entró en su genealogía y activó ` +
          `el hábitat ${habitat}.`,
      },
    ].slice(-160),
  };
}

function rotar<T>(lista: T[], n: number): T[] {
  const giro = ((n % lista.length) + lista.length) % lista.length;
  return [...lista.slice(giro), ...lista.slice(0, giro)];
}

function decimal(n: number): string {
  return Math.max(0, n).toFixed(2);
}

// === EMBRION V5 · PERFIL COMPOSITIVO ===
type PerfilCompositivoV5 = {
  repeticion: number;
  fragmentacion: number;
  suspension: number;
  cuerpo: number;
  densidad: number;
  vacio: number;
  pulso: "suspendido" | "intermitente" | "roto" | "estable";
};

function clamp01(v: number): number {
  return Math.max(0, Math.min(1, v));
}

function perfilCompositivoV5(texto: string): PerfilCompositivoV5 {
  const lista = relevantes(texto).map(normalizar);
  const todas = palabras(texto);
  const lineas = texto.split(/\n+/).map(x => x.trim()).filter(Boolean);
  const freq = new Map<string, number>();
  lista.forEach(p => freq.set(p, (freq.get(p) ?? 0) + 1));
  const extras = [...freq.values()].reduce((n, v) => n + Math.max(0, v - 1), 0);
  const repeticion = clamp01(lista.length ? extras / lista.length : 0);
  const breves = lineas.filter(l => palabras(l).length <= 3).length;
  const signos = (texto.match(/[,.…;:!?—-]/g) ?? []).length;
  const fragmentacion = clamp01(
    (lineas.length ? breves / lineas.length : 0) * 0.55 +
    (todas.length ? signos / todas.length : 0) * 1.45
  );
  const a = analizarPoema(texto);
  const cuerpo = clamp01((a.habitats.pulso * 0.52 + a.habitats.maquina * 0.30) / 100 + repeticion * 0.30);
  const suspension = clamp01((a.habitats.deriva * 0.48 + a.habitats.espectral * 0.28) / 100 + fragmentacion * 0.20 - cuerpo * 0.18);
  const densidad = clamp01(0.14 + Math.min(0.42, todas.length / 90) + cuerpo * 0.25 + repeticion * 0.35 - suspension * 0.10);
  const vacio = clamp01(0.82 - densidad * 0.72 + suspension * 0.28 - repeticion * 0.20);

  let pulso: PerfilCompositivoV5['pulso'];
  if (repeticion >= 0.15) pulso = 'estable';
  else if (suspension >= 0.56) pulso = 'suspendido';
  else if (fragmentacion >= 0.58) pulso = 'roto';
  else pulso = 'intermitente';

  return { repeticion, fragmentacion, suspension, cuerpo, densidad, vacio, pulso };
}
// === FIN EMBRION V5 · PERFIL COMPOSITIVO ===

export function bpmActual(organismo: Organismo): number {
  const texto = [organismo.poema, ...organismo.injertos].filter(Boolean).join("\n");
  const p = perfilCompositivoV5(texto);
  return limitar(
    organismo.bpmBase +
      p.repeticion * 34 +
      p.cuerpo * 10 +
      p.fragmentacion * 5 -
      p.suspension * 24 -
      p.vacio * 8,
    48,
    150,
  );
}

export function duracionComposicionMinutos(
  organismo: Organismo,
): number {
  return Math.round(
    (CICLOS_COMPOSICION * 4 * 10) / bpmActual(organismo),
  ) / 10;
}


// === EMBRION V6 · GRAMATICA DE OPERADORES ===

type OperadorV6 =
  | "RESPIRAR"
  | "PERMANECER"
  | "RETORNAR"
  | "VACIAR"
  | "CONTRAER"
  | "DESPOJAR"
  | "RECORDAR"
  | "EROSIONAR"
  | "EXPANDIR"
  | "NO_RESOLVER"
  | "HERIR";

type LecturaOperadoresV6 = {
  operadores: OperadorV6[];
  repeticion: number;
  fragmentacion: number;
  suspension: number;
  vacio: number;
  cuerpo: number;
  memoria: number;
  pulso: "suspendido" | "intermitente" | "roto" | "estable";
  noResuelto: boolean;
};

function clamp01V6(valor: number): number {
  return Math.max(0, Math.min(1, valor));
}

function rotarSeguroV6<T>(items: T[], desplazamiento: number): T[] {
  if (!items.length) return [];
  const n = ((desplazamiento % items.length) + items.length) % items.length;
  return [...items.slice(n), ...items.slice(0, n)];
}

function lecturaOperadoresV6(texto: string): LecturaOperadoresV6 {
  const analisis = analizarPoema(texto);
  const h = analisis.habitats;
  const lista = relevantes(texto).map(normalizar);
  const todas = palabras(texto);
  const normal = normalizar(texto);

  const lineas = texto
    .split(/\n+/)
    .map((linea) => linea.trim())
    .filter(Boolean);

  const frecuencia = new Map<string, number>();
  lista.forEach((palabra) => {
    frecuencia.set(palabra, (frecuencia.get(palabra) ?? 0) + 1);
  });

  const repetidas = [...frecuencia.values()].reduce(
    (total, cantidad) => total + Math.max(0, cantidad - 1),
    0,
  );

  const repeticion = clamp01V6(
    lista.length ? repetidas / lista.length : 0,
  );

  const signos = (texto.match(/[,.…;:!?—-]/g) ?? []).length;
  const breves = lineas.filter((linea) => palabras(linea).length <= 3).length;
  const proporcionBreves = lineas.length ? breves / lineas.length : 0;
  const densidadSignos = todas.length ? signos / todas.length : 0;
  const blancos = (texto.match(/\n\s*\n/g) ?? []).length;

  const fragmentacion = clamp01V6(
    proporcionBreves * 0.58 + densidadSignos * 2.7,
  );

  const cuerpo = clamp01V6(
    (h.pulso * 0.5 + h.maquina * 0.28) / 100 + repeticion * 0.26,
  );

  const memoria = clamp01V6(
    (h.memoria * 0.52 + h.espectral * 0.28) / 100 +
      repeticion * 0.24 +
      (/memoria|recuerda|recordar|olvido|vuelve|regresa|retorna/.test(normal) ? 0.18 : 0),
  );

  const suspension = clamp01V6(
    (h.deriva * 0.38 + h.espectral * 0.28) / 100 +
      proporcionBreves * 0.24 +
      (/espera|silencio|nadie|nunca|quiet|permanece|queda/.test(normal) ? 0.20 : 0) -
      cuerpo * 0.16,
  );

  const vacio = clamp01V6(
    0.30 +
      blancos * 0.055 +
      suspension * 0.38 +
      proporcionBreves * 0.20 -
      cuerpo * 0.20,
  );

  const ultimaLinea = normalizar(lineas[lineas.length - 1] ?? "");
  const noResuelto =
    /nadie|nunca|espera|queda|permanece|sin|pero|no |no$|olvido|ausencia/.test(ultimaLinea) ||
    /\?$/.test(texto.trim());

  let pulso: LecturaOperadoresV6["pulso"];
  if (suspension >= 0.58 && cuerpo < 0.58) pulso = "suspendido";
  else if (fragmentacion >= 0.58) pulso = "roto";
  else if (repeticion >= 0.16 || cuerpo >= 0.58) pulso = "estable";
  else pulso = "intermitente";

  const operadores: OperadorV6[] = [];
  const add = (operador: OperadorV6) => {
    if (operadores[operadores.length - 1] !== operador) operadores.push(operador);
  };

  if (vacio >= 0.60) add("VACIAR");
  else if (suspension >= 0.42) add("RESPIRAR");
  else add("PERMANECER");

  const vistas = new Map<string, number>();

  lineas.forEach((linea) => {
    const limpia = normalizar(linea);
    const nPalabras = palabras(linea).length;
    const veces = (vistas.get(limpia) ?? 0) + 1;
    vistas.set(limpia, veces);

    if (/respira|respirar|aire|aliento/.test(limpia)) add("RESPIRAR");
    if (/permanece|queda|espera|todavia|sigue|quiet/.test(limpia)) add("PERMANECER");
    if (/vuelve|regresa|retorna|otra vez/.test(limpia) || veces > 1) add("RETORNAR");
    if (/apaga|desaparece|silencio|ausencia|nadie|vacio|borra/.test(limpia)) add("VACIAR");
    if (/recuerda|memoria|recordar|olvido|eco/.test(limpia)) add("RECORDAR");
    if (/herida|roto|rompe|corte|marca|cicatriz|fractura/.test(limpia)) add("HERIR");

    if (nPalabras <= 2) add("CONTRAER");
    if (nPalabras >= 10 && suspension < 0.68) add("EXPANDIR");
  });

  if (fragmentacion >= 0.55) add("EROSIONAR");
  if (repeticion >= 0.16) add("RETORNAR");
  if (vacio >= 0.58) add("DESPOJAR");
  if (cuerpo >= 0.62 && vacio < 0.58) add("EXPANDIR");
  if (memoria >= 0.55) add("RECORDAR");
  if (noResuelto) add("NO_RESOLVER");

  const compactos = operadores.filter((operador, index) =>
    index === 0 || operador !== operadores[index - 1],
  );

  const final = compactos.slice(0, 9);
  if (!final.length) final.push("RESPIRAR", "PERMANECER", "RECORDAR");

  return {
    operadores: final,
    repeticion,
    fragmentacion,
    suspension,
    vacio,
    cuerpo,
    memoria,
    pulso,
    noResuelto,
  };
}

// === FIN EMBRION V6 · GRAMATICA DE OPERADORES ===

export function codigoStrudel(organismo: Organismo): string {
  const textoVivo = [organismo.poema, ...organismo.injertos]
    .filter(Boolean)
    .join("\n");

  const analisis = analizarPoema(textoVivo);
  const lectura = lecturaOperadoresV6(textoVivo);
  const h = organismo.habitats;
  const bpm = bpmActual(organismo);

  const escalaBase = ESCALAS[analisis.semilla % ESCALAS.length] ?? ["c2", "eb2", "g2", "bb2"];
  const materia = [...new Set([
    ...organismo.notas,
    ...analisis.notas,
    ...escalaBase,
  ])].filter(Boolean);

  const notas = rotarSeguroV6(
    materia.length ? materia : ["c2", "eb2", "g2", "bb2"],
    hashTexto(textoVivo) + organismo.edad + organismo.diario.length,
  );

  const n1 = notas[0] ?? "c2";
  const n2 = notas[1] ?? notas[0] ?? "eb2";
  const n3 = notas[2] ?? notas[0] ?? "g2";
  const n4 = notas[3] ?? notas[1] ?? "bb2";
  const n5 = notas[4] ?? notas[2] ?? "d3";

  const motivoA = [n1, n2].join(" ");
  const motivoB = [n2, n3, n4].join(" ");
  const motivoC = [n4, n2, n5].join(" ");
  const retorno = [n1, n3, n2].join(" ");
  const noResuelto = [n2, n4, n3].join(" ");

  const osciladores = ["sine", "triangle", "sawtooth", "square"] as const;
  const oscA = osciladores[analisis.semilla % osciladores.length];
  const oscB = osciladores[Math.floor(analisis.semilla / 7) % osciladores.length];
  const oscC = osciladores[Math.floor(analisis.semilla / 19) % osciladores.length];

  const nota = (
    patron: string,
    osc: string,
    slow: number,
    gain: number,
    room: number,
  ) => `note("<${patron}>")
    .s("${osc}")
    .slow(${slow})
    .gain(${decimal(gain)})
    .room(${decimal(room)})`;

  const sub = (
    patron: string,
    slow: number,
    gain: number,
    cutoff: number,
  ) => `note("<${patron}>")
    .s("sine")
    .slow(${slow})
    .gain(${decimal(gain)})
    .lpf(${Math.round(cutoff)})`;

  const percusion = (
    patron: string,
    gain: number,
  ) => `s("${patron}").gain(${decimal(gain)})`;

  const aire = (
    patron: string,
    gain: number,
    room: number,
  ) => `note("<${patron}>")
    .s("triangle")
    .slow(12)
    .gain(${decimal(gain)})
    .room(${decimal(room)})
    .delay(${decimal(0.08 + lectura.memoria * 0.28)})`;

  const stackDe = (...capas: string[]) => `stack(\n${capas.filter(Boolean).join(",\n")}\n)`;

  const permitePulso = lectura.pulso !== "suspendido";
  const pulsoIntermitente = lectura.pulso === "roto"
    ? "bd(3,8)"
    : lectura.pulso === "estable"
      ? "bd*4"
      : "bd ~ ~ bd";

  function materialDe(operador: OperadorV6, indice: number): string {
    const giro = indice % 3;
    const motivo = giro === 0 ? motivoA : giro === 1 ? motivoB : motivoC;
    const osc = giro === 0 ? oscA : giro === 1 ? oscB : oscC;

    switch (operador) {
      case "RESPIRAR":
        return stackDe(
          nota(motivoA, oscA, 10 + Math.round(lectura.suspension * 4), 0.07 + h.deriva / 900, 0.68 + lectura.suspension * 0.22),
          aire(`${n3} ~ ${n2} ~`, 0.025 + lectura.memoria * 0.06, 0.78),
        );

      case "PERMANECER":
        return stackDe(
          nota(`${n1} ~ ${n1} ~`, "sine", 9, 0.08 + lectura.repeticion * 0.12, 0.58),
          lectura.vacio < 0.55
            ? sub(`${n1} ~`, 8, 0.05 + lectura.cuerpo * 0.10, 520 + lectura.cuerpo * 420)
            : "",
        );

      case "RETORNAR":
        return stackDe(
          nota(retorno, oscB, 5, 0.10 + lectura.repeticion * 0.18, 0.46 + lectura.memoria * 0.20),
          nota(`${n1} ~ ${n2} ~`, "triangle", 8, 0.04 + lectura.memoria * 0.08, 0.72),
          permitePulso && lectura.cuerpo > 0.44
            ? percusion(pulsoIntermitente, 0.08 + lectura.cuerpo * 0.16)
            : "",
        );

      case "VACIAR":
        return stackDe(
          aire(`${n2} ~ ~ ~`, 0.025 + lectura.memoria * 0.045, 0.90),
        );

      case "CONTRAER":
        return stackDe(
          nota(`${n2} ${n1}`, oscC, 6, 0.08 + lectura.fragmentacion * 0.12, 0.34),
          permitePulso && lectura.cuerpo > 0.52
            ? percusion("bd ~ ~ ~", 0.07 + lectura.cuerpo * 0.12)
            : "",
        );

      case "DESPOJAR":
        return stackDe(
          nota(`${n1} ~`, "sine", 12, 0.045 + lectura.memoria * 0.05, 0.82),
        );

      case "RECORDAR":
        return stackDe(
          nota(`${n1} ~ ${n3} ~`, "triangle", 8, 0.055 + lectura.memoria * 0.11, 0.72 + lectura.memoria * 0.16),
          nota(`${n2} ~ ~ ${n1}`, oscA, 11, 0.035 + lectura.memoria * 0.07, 0.84),
        );

      case "EROSIONAR":
        return stackDe(
          nota(motivo, osc, 5, 0.07 + lectura.fragmentacion * 0.13, 0.50)
            + `.lpf(${Math.round(420 + (1 - lectura.fragmentacion) * 1700)})`,
          lectura.cuerpo > 0.40
            ? percusion(lectura.pulso === "roto" ? "[~ hh]*8" : "~ hh ~ ~", 0.035 + lectura.fragmentacion * 0.08)
            : "",
        );

      case "EXPANDIR":
        return stackDe(
          nota(`${motivoA} ${n4}`, oscA, 3, 0.12 + lectura.cuerpo * 0.16, 0.42),
          sub(`${n1} ${n3}`, 2, 0.10 + lectura.cuerpo * 0.22, 760 + lectura.cuerpo * 900),
          permitePulso && lectura.cuerpo > 0.42
            ? percusion(pulsoIntermitente, 0.14 + lectura.cuerpo * 0.24)
            : "",
          permitePulso && lectura.cuerpo > 0.58
            ? percusion(lectura.fragmentacion > 0.55 ? "[~ hh]*8" : "hh*8", 0.04 + lectura.fragmentacion * 0.07)
            : "",
        );

      case "HERIR":
        return stackDe(
          nota(`${n4} ${n2} ~ ${n5}`, "square", 4, 0.08 + lectura.fragmentacion * 0.16, 0.48)
            + `.delay(${decimal(0.06 + lectura.fragmentacion * 0.18)})`,
          lectura.cuerpo > 0.36
            ? percusion("bd(5,12)", 0.08 + lectura.fragmentacion * 0.16)
            : "",
        );

      case "NO_RESOLVER":
        return stackDe(
          nota(noResuelto, oscB, 10, 0.055 + lectura.suspension * 0.08, 0.78),
          aire(`${n4} ~ ${n2} ~`, 0.025 + lectura.memoria * 0.05, 0.92),
        );
    }
  }

  const pesos = lectura.operadores.map((operador) => {
    switch (operador) {
      case "VACIAR": return 7 + lectura.vacio * 5;
      case "RESPIRAR": return 7 + lectura.suspension * 5;
      case "PERMANECER": return 8 + lectura.repeticion * 7;
      case "RETORNAR": return 6 + lectura.repeticion * 7;
      case "CONTRAER": return 4 + lectura.fragmentacion * 4;
      case "DESPOJAR": return 6 + lectura.vacio * 5;
      case "RECORDAR": return 7 + lectura.memoria * 6;
      case "EROSIONAR": return 5 + lectura.fragmentacion * 5;
      case "EXPANDIR": return 7 + lectura.cuerpo * 7;
      case "HERIR": return 4 + lectura.fragmentacion * 5;
      case "NO_RESOLVER": return 8 + lectura.suspension * 5;
    }
  });

  const totalPesos = pesos.reduce((total, valor) => total + valor, 0);
  const ciclos = pesos.map((peso) => Math.max(3, Math.floor((peso / totalPesos) * CICLOS_COMPOSICION)));

  let diferencia = CICLOS_COMPOSICION - ciclos.reduce((total, valor) => total + valor, 0);
  let cursor = 0;

  while (diferencia > 0) {
    ciclos[cursor % ciclos.length] += 1;
    cursor += 1;
    diferencia -= 1;
  }

  cursor = ciclos.length - 1;
  while (diferencia < 0) {
    const indice = ((cursor % ciclos.length) + ciclos.length) % ciclos.length;
    if (ciclos[indice] > 3) {
      ciclos[indice] -= 1;
      diferencia += 1;
    }
    cursor -= 1;
  }

  const escenas = lectura.operadores.map((operador, indice) => ({
    nombre: `escena${indice}`,
    operador,
    codigo: materialDe(operador, indice),
  }));

  const declaraciones = escenas
    .map((escena) => `const ${escena.nombre} = ${escena.codigo}`)
    .join("\n\n");

  const arreglo = escenas
    .map((escena, indice) => `  [${ciclos[indice]}, ${escena.nombre}]`)
    .join(",\n");

  return `/*
ORGANISMO · MOTOR COMPOSITIVO V6
GRAMÁTICA DE OPERADORES
${organismo.codigo} · ${organismo.nombre}
Pulso: ${lectura.pulso}
Repetición: ${Math.round(lectura.repeticion * 100)}
Fragmentación: ${Math.round(lectura.fragmentacion * 100)}
Suspensión: ${Math.round(lectura.suspension * 100)}
Vacío: ${Math.round(lectura.vacio * 100)}
Operadores: ${lectura.operadores.join(" → ")}
Ciclos: ${ciclos.join(" · ")}
*/

setcpm(${bpm}/4)

${declaraciones}

arrange(
${arreglo}
)
`;
}


function base64Utf8(texto: string): string {
  const bytes = new TextEncoder().encode(texto);
  let binary = "";

  for (const byte of bytes) {
    binary += String.fromCharCode(byte);
  }

  return globalThis.btoa(binary);
}

export function urlStrudel(codigo: string): string {
  return `https://strudel.cc/#${base64Utf8(codigo)}`;
}
