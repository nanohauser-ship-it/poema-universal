export type Habitat =
  | "deriva"
  | "pulso"
  | "fractura"
  | "espectral"
  | "maquina"
  | "memoria";

export type Etapa =
  | "embrion"
  | "germinacion"
  | "formacion"
  | "cuerpo"
  | "mutacion"
  | "madurez"
  | "latencia";

export type EntradaVital = {
  id: string;
  dia: number;
  fecha: string;
  titulo: string;
  texto: string;
  habitat: Habitat;
};

export type Organismo = {
  version: 4;
  id: string;
  codigo: string;
  nombre: string;
  poema: string;
  nacimiento: string;
  ultimaEvolucion: string;
  ultimaInteraccion: string;
  edad: number;
  etapa: Etapa;
  semilla: number;
  reliquia: string;
  bpmBase: number;
  tonalidad: string;
  habitats: Record<Habitat, number>;
  energia: number;
  estabilidad: number;
  memoriaVital: number;
  complejidad: number;
  notas: string[];
  diario: EntradaVital[];
  injertos: string[];
};

export const HABITATS: Habitat[] = [
  "deriva",
  "pulso",
  "fractura",
  "espectral",
  "maquina",
  "memoria",
];

export const CICLOS_COMPOSICION = 56;

const STOP = new Set([
  "a", "al", "ante", "bajo", "como", "con", "de", "del", "desde", "el",
  "ella", "en", "entre", "era", "es", "esta", "fue", "ha", "hasta", "la",
  "las", "lo", "los", "más", "mas", "me", "mi", "muy", "no", "nos", "o",
  "para", "pero", "por", "que", "se", "sin", "sobre", "su", "sus", "te",
  "tu", "un", "una", "y", "ya",
]);

const VOCABULARIO: Record<Habitat, string[]> = {
  deriva: [
    "agua", "mar", "rio", "lluvia", "aire", "viento", "nube", "niebla",
    "sueño", "sueno", "flotar", "lejos", "noche", "lento",
  ],
  pulso: [
    "cuerpo", "piel", "sangre", "corazon", "latido", "hambre", "carne",
    "mano", "pie", "boca", "deseo", "golpe", "ritmo",
  ],
  fractura: [
    "roto", "corte", "caer", "grito", "herida", "fragmento", "ruina",
    "nunca", "partir", "fractura", "error", "vacio",
  ],
  espectral: [
    "sombra", "fantasma", "muerte", "muerto", "silencio", "ausencia",
    "nadie", "desaparecer", "olvido", "eco", "voz", "alma",
  ],
  maquina: [
    "maquina", "motor", "hierro", "metal", "codigo", "cable", "ciudad",
    "fabrica", "tren", "reloj", "ruido",
  ],
  memoria: [
    "memoria", "recuerdo", "nombre", "ayer", "antes", "infancia", "madre",
    "padre", "fotografia", "cuaderno", "historia", "volver", "regresar",
  ],
};

const ESCALAS = [
  ["c2", "eb2", "g2", "bb2", "d3", "f3"],
  ["d2", "f2", "a2", "c3", "e3", "g3"],
  ["eb2", "gb2", "bb2", "db3", "f3", "ab3"],
  ["f2", "ab2", "c3", "eb3", "g3", "bb3"],
];

const TONALIDADES = ["C menor", "D dórico", "Eb menor", "F lidio"];

const MUTACIONES: Record<Habitat, string[]> = {
  deriva: [
    "Una corriente desplazó la armonía",
    "La membrana comenzó a flotar",
    "El espacio se volvió más profundo",
  ],
  pulso: [
    "Apareció un nuevo latido",
    "El subgrave adquirió cuerpo",
    "La respiración encontró una cadencia",
  ],
  fractura: [
    "La métrica desarrolló una cicatriz",
    "Un motivo se partió en fragmentos",
    "El silencio cortó la secuencia",
  ],
  espectral: [
    "La palabra reliquia dejó una sombra",
    "Una presencia atravesó el núcleo",
    "Nació una cola espectral",
  ],
  maquina: [
    "Apareció una estructura metálica",
    "El reloj interno ganó precisión",
    "Una secuencia mecánica ocupó el borde",
  ],
  memoria: [
    "Regresó una forma del primer día",
    "El organismo recordó una nota perdida",
    "Un eco antiguo volvió transformado",
  ],
};

function normalizar(texto: string): string {
  return texto
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "");
}

export function hashTexto(texto: string): number {
  let resultado = 2166136261;
  for (let i = 0; i < texto.length; i += 1) {
    resultado ^= texto.charCodeAt(i);
    resultado = Math.imul(resultado, 16777619);
  }
  return Math.abs(resultado >>> 0);
}

function azar(semilla: number, indice: number): number {
  const valor = Math.sin(semilla * 0.000017 + indice * 71.923) * 43758.5453;
  return valor - Math.floor(valor);
}

function limitar(valor: number, min = 0, max = 100): number {
  return Math.max(min, Math.min(max, Math.round(valor)));
}

function palabras(texto: string): string[] {
  return (
    texto.match(/[A-Za-zÁÉÍÓÚÜÑáéíóúüñ]+(?:['’-][A-Za-zÁÉÍÓÚÜÑáéíóúüñ]+)*/g) ??
    []
  );
}

function relevantes(texto: string): string[] {
  return palabras(texto).filter((palabra) => {
    const limpia = normalizar(palabra);
    return limpia.length > 2 && !STOP.has(limpia);
  });
}

function reliquiaDe(texto: string): string {
  const lista = relevantes(texto);
  if (!lista.length) return "silencio";

  const frecuencia = new Map<string, { original: string; n: number }>();
  lista.forEach((palabra) => {
    const clave = normalizar(palabra);
    const anterior = frecuencia.get(clave);
    frecuencia.set(clave, {
      original: anterior?.original ?? palabra,
      n: (anterior?.n ?? 0) + 1,
    });
  });

  return [...frecuencia.values()].sort(
    (a, b) =>
      b.n * 10 +
      b.original.length -
      (a.n * 10 + a.original.length),
  )[0].original;
}

function etapaPorEdad(edad: number): Etapa {
  if (edad <= 0) return "embrion";
  if (edad <= 3) return "germinacion";
  if (edad <= 7) return "formacion";
  if (edad <= 14) return "cuerpo";
  if (edad <= 30) return "mutacion";
  return "madurez";
}

function fechaHoy(): string {
  return new Date().toISOString().slice(0, 10);
}

function diasEntre(desde: string, hasta: string): number {
  const a = new Date(`${desde}T00:00:00`).getTime();
  const b = new Date(`${hasta}T00:00:00`).getTime();
  return Math.max(0, Math.floor((b - a) / 86400000));
}

export function analizarPoema(texto: string) {
  const lista = relevantes(texto);
  const semilla = hashTexto(texto || "silencio");
  const signos = (texto.match(/[,.…;:!?—-]/g) ?? []).length;
  const lineas = Math.max(
    1,
    texto.split(/\n+/).map((x) => x.trim()).filter(Boolean).length,
  );

  const habitats = {} as Record<Habitat, number>;

  HABITATS.forEach((habitat, indice) => {
    const diccionario = new Set(VOCABULARIO[habitat].map(normalizar));
    const coincidencias = lista.filter((p) =>
      diccionario.has(normalizar(p)),
    ).length;

    habitats[habitat] = limitar(
      18 +
        coincidencias * 14 +
        azar(semilla, indice + 1) * 18 +
        (habitat === "fractura" ? signos * 2 : 0) +
        (habitat === "deriva" ? lineas * 2 : 0),
      7,
      96,
    );
  });

  const escala = ESCALAS[semilla % ESCALAS.length];
  const notas = [...new Set(lista.map((p) => escala[hashTexto(p) % escala.length]))]
    .slice(0, 7);

  return {
    semilla,
    reliquia: reliquiaDe(texto),
    habitats,
    notas: notas.length ? notas : escala.slice(0, 4),
    bpmBase: limitar(
      65 + habitats.pulso * 0.55 + habitats.maquina * 0.16 -
        habitats.deriva * 0.18,
      45,
      145,
    ),
    tonalidad: TONALIDADES[semilla % TONALIDADES.length],
  };
}

export function incubar(nombre: string, poema: string): Organismo {
  const fecha = fechaHoy();
  const analisis = analizarPoema(poema);
  const semilla = hashTexto(`${poema}|${nombre}|${Date.now()}`);
  const codigo = `OE-${String(semilla % 100000).padStart(5, "0")}`;

  return {
    version: 4,
    id: `${codigo}-${Date.now()}`,
    codigo,
    nombre: nombre.trim() || analisis.reliquia,
    poema,
    nacimiento: fecha,
    ultimaEvolucion: fecha,
    ultimaInteraccion: fecha,
    edad: 0,
    etapa: "embrion",
    semilla,
    reliquia: analisis.reliquia,
    bpmBase: analisis.bpmBase,
    tonalidad: analisis.tonalidad,
    habitats: analisis.habitats,
    energia: limitar(28 + analisis.habitats.pulso * 0.25),
    estabilidad: limitar(
      52 + analisis.habitats.memoria * 0.15 -
        analisis.habitats.fractura * 0.12,
    ),
    memoriaVital: limitar(18 + analisis.habitats.memoria * 0.35),
    complejidad: 14,
    notas: analisis.notas,
    injertos: [],
    diario: [
      {
        id: `nacimiento-${semilla}`,
        dia: 0,
        fecha,
        titulo: "El poema fue incubado",
        texto:
          `${codigo} nació alrededor de la palabra «${analisis.reliquia}». ` +
          "Todavía no posee una forma musical cerrada.",
        habitat: "memoria",
      },
    ],
  };
}

function habitatDominante(
  organismo: Organismo,
  dia: number,
): Habitat {
  return HABITATS.map((habitat, indice) => ({
    habitat,
    valor:
      organismo.habitats[habitat] +
      azar(organismo.semilla, dia * 13 + indice) * 42,
  })).sort((a, b) => b.valor - a.valor)[0].habitat;
}

function evolucionarDia(
  organismo: Organismo,
  dia: number,
  fecha: string,
): Organismo {
  const habitat = habitatDominante(organismo, dia);
  const opciones = MUTACIONES[habitat];
  const titulo =
    opciones[
      Math.floor(azar(organismo.semilla, dia * 29) * opciones.length) %
        opciones.length
    ];

  const entrada: EntradaVital = {
    id: `dia-${dia}-${organismo.semilla}`,
    dia,
    fecha,
    titulo,
    habitat,
    texto:
      `${titulo}. El hábitat ${habitat} modificó su densidad, ` +
      "su memoria o su respiración electrónica.",
  };

  return {
    ...organismo,
    edad: dia,
    etapa: etapaPorEdad(dia),
    ultimaEvolucion: fecha,
    energia: limitar(
      organismo.energia + (habitat === "pulso" ? 5 : 2) -
        (habitat === "deriva" ? 1 : 0),
    ),
    estabilidad: limitar(
      organismo.estabilidad + (habitat === "memoria" ? 3 : 0) -
        (habitat === "fractura" ? 4 : 1),
    ),
    memoriaVital: limitar(
      organismo.memoriaVital + (habitat === "memoria" ? 6 : 2),
    ),
    complejidad: limitar(organismo.complejidad + 3),
    diario: [...organismo.diario, entrada].slice(-160),
  };
}

export function evolucionarHastaHoy(organismo: Organismo): {
  organismo: Organismo;
  ciclos: number;
} {
  const hoy = fechaHoy();
  const ciclos = diasEntre(organismo.ultimaEvolucion, hoy);
  let actual = organismo;

  for (let i = 1; i <= ciclos; i += 1) {
    const fecha = new Date(`${organismo.ultimaEvolucion}T12:00:00`);
    fecha.setDate(fecha.getDate() + i);
    actual = evolucionarDia(
      actual,
      organismo.edad + i,
      fecha.toISOString().slice(0, 10),
    );
  }

  if (diasEntre(actual.ultimaInteraccion, hoy) >= 14) {
    actual = {
      ...actual,
      etapa: "latencia",
      energia: limitar(actual.energia - 14),
    };
  }

  return { organismo: actual, ciclos };
}

export function mutarAhora(organismo: Organismo): Organismo {
  const indice = organismo.diario.length + 700;
  const habitat = habitatDominante(organismo, indice);
  const opciones = MUTACIONES[habitat];
  const titulo =
    opciones[Math.floor(azar(organismo.semilla, indice) * opciones.length)];

  return {
    ...organismo,
    ultimaInteraccion: fechaHoy(),
    complejidad: limitar(organismo.complejidad + 3),
    estabilidad: limitar(
      organismo.estabilidad - (habitat === "fractura" ? 4 : 1),
    ),
    diario: [
      ...organismo.diario,
      {
        id: `lab-${indice}-${Date.now()}`,
        dia: organismo.edad,
        fecha: fechaHoy(),
        titulo,
        habitat,
        texto:
          `${titulo}. Fue una mutación inducida y no alteró su edad cronológica.`,
      },
    ].slice(-160),
  };
}

export function despertar(organismo: Organismo): Organismo {
  return {
    ...organismo,
    etapa: etapaPorEdad(organismo.edad),
    energia: limitar(organismo.energia + 12),
    ultimaInteraccion: fechaHoy(),
  };
}

export function injertar(
  organismo: Organismo,
  verso: string,
): Organismo {
  const limpio = verso.trim();
  if (!limpio) return organismo;

  const habitat = HABITATS[hashTexto(limpio) % HABITATS.length];

  return {
    ...organismo,
    ultimaInteraccion: fechaHoy(),
    energia: limitar(organismo.energia + 5),
    complejidad: limitar(organismo.complejidad + 5),
    memoriaVital: limitar(organismo.memoriaVital + 3),
    injertos: [...organismo.injertos, limpio].slice(-50),
    diario: [
      ...organismo.diario,
      {
        id: `injerto-${Date.now()}`,
        dia: organismo.edad,
        fecha: fechaHoy(),
        titulo: "El organismo recibió un injerto",
        habitat,
        texto:
          `«${limpio.slice(0, 120)}» entró en su genealogía y activó ` +
          `el hábitat ${habitat}.`,
      },
    ].slice(-160),
  };
}

function rotar<T>(lista: T[], n: number): T[] {
  const giro = ((n % lista.length) + lista.length) % lista.length;
  return [...lista.slice(giro), ...lista.slice(0, giro)];
}

function decimal(n: number): string {
  return Math.max(0, n).toFixed(2);
}

// === EMBRION V5 · PERFIL COMPOSITIVO ===
type PerfilCompositivoV5 = {
  repeticion: number;
  fragmentacion: number;
  suspension: number;
  cuerpo: number;
  densidad: number;
  vacio: number;
  pulso: "suspendido" | "intermitente" | "roto" | "estable";
};

function clamp01(v: number): number {
  return Math.max(0, Math.min(1, v));
}

function perfilCompositivoV5(texto: string): PerfilCompositivoV5 {
  const lista = relevantes(texto).map(normalizar);
  const todas = palabras(texto);
  const lineas = texto.split(/\n+/).map(x => x.trim()).filter(Boolean);
  const freq = new Map<string, number>();
  lista.forEach(p => freq.set(p, (freq.get(p) ?? 0) + 1));
  const extras = [...freq.values()].reduce((n, v) => n + Math.max(0, v - 1), 0);
  const repeticion = clamp01(lista.length ? extras / lista.length : 0);
  const breves = lineas.filter(l => palabras(l).length <= 3).length;
  const signos = (texto.match(/[,.…;:!?—-]/g) ?? []).length;
  const fragmentacion = clamp01(
    (lineas.length ? breves / lineas.length : 0) * 0.55 +
    (todas.length ? signos / todas.length : 0) * 1.45
  );
  const a = analizarPoema(texto);
  const cuerpo = clamp01((a.habitats.pulso * 0.52 + a.habitats.maquina * 0.30) / 100 + repeticion * 0.30);
  const suspension = clamp01((a.habitats.deriva * 0.48 + a.habitats.espectral * 0.28) / 100 + fragmentacion * 0.20 - cuerpo * 0.18);
  const densidad = clamp01(0.14 + Math.min(0.42, todas.length / 90) + cuerpo * 0.25 + repeticion * 0.35 - suspension * 0.10);
  const vacio = clamp01(0.82 - densidad * 0.72 + suspension * 0.28 - repeticion * 0.20);

  let pulso: PerfilCompositivoV5['pulso'];
  if (repeticion >= 0.15) pulso = 'estable';
  else if (suspension >= 0.56) pulso = 'suspendido';
  else if (fragmentacion >= 0.58) pulso = 'roto';
  else pulso = 'intermitente';

  return { repeticion, fragmentacion, suspension, cuerpo, densidad, vacio, pulso };
}
// === FIN EMBRION V5 · PERFIL COMPOSITIVO ===

export function bpmActual(organismo: Organismo): number {
  const texto = [organismo.poema, ...organismo.injertos].filter(Boolean).join("\n");
  const p = perfilCompositivoV5(texto);
  return limitar(
    organismo.bpmBase +
      p.repeticion * 34 +
      p.cuerpo * 10 +
      p.fragmentacion * 5 -
      p.suspension * 24 -
      p.vacio * 8,
    48,
    150,
  );
}

export function duracionComposicionMinutos(
  organismo: Organismo,
): number {
  return Math.round(
    (CICLOS_COMPOSICION * 4 * 10) / bpmActual(organismo),
  ) / 10;
}

export function codigoStrudel(organismo: Organismo): string {
  const texto = [organismo.poema, ...organismo.injertos].filter(Boolean).join("\n");
  const a = analizarPoema(texto);
  const p = perfilCompositivoV5(texto);
  const base = organismo.notas.length ? organismo.notas : a.notas;
  const notas = rotar(base.length ? base : ["c2", "eb2", "g2", "bb2"], organismo.edad + organismo.diario.length);
  const n = p.densidad > 0.65 ? 5 : p.vacio > 0.60 ? 2 : 3;
  const mA = notas.slice(0, n).join(" ");
  const mB = rotar(notas, 2).slice(0, Math.max(2, n)).join(" ");
  const mC = rotar(notas, 4).slice(0, Math.max(2, n - 1)).join(" ");
  const bajo = notas.slice(0, 3).map(x => x.replace(/[3-7]$/, "2")).join(" ");
  const reliquia = notas[hashTexto(organismo.reliquia) % notas.length] ?? "c2";
  const final = notas[notas.length - 1] ?? reliquia;
  const seed = a.semilla;
  const oscs = ["sine", "triangle", "sawtooth"] as const;
  const o1 = oscs[seed % 3];
  const o2 = oscs[Math.floor(seed / 7) % 3];
  const bpm = bpmActual(organismo);

  const kick = p.pulso === "estable" ? "bd*4" : p.pulso === "roto" ? "bd(3,8)" : p.pulso === "intermitente" ? "bd ~ ~ bd" : "bd ~ ~ ~";
  const hats = p.densidad > 0.68 ? "hh*8" : p.densidad > 0.42 ? "[~ hh]*4" : "~ hh ~ ~";
  const clap = p.repeticion > 0.15 || p.cuerpo > 0.55 ? "~ cp ~ cp" : "~ ~ cp ~";

  const mel = (motivo: string, osc: string, slow: number, gain: number, room: number) => `note("<${motivo}>").s("${osc}").slow(${slow}).gain(${decimal(gain)}).room(${decimal(room)})`;
  const sub = (slow: number, gain: number) => `note("<${bajo}>").s("sine").slow(${slow}).gain(${decimal(gain)}).lpf(${Math.round(500 + p.cuerpo * 1200)})`;
  const bd = (gain: number, patron = kick) => `s("${patron}").gain(${decimal(gain)})`;
  const hh = (gain: number, patron = hats) => `s("${patron}").gain(${decimal(gain)}).hpf(${Math.round(4400 + p.fragmentacion * 1800)})`;
  const cp = `s("${clap}").gain(${decimal(0.04 + p.cuerpo * 0.14)}).room(${decimal(0.08 + p.suspension * 0.20)})`;
  const eco = `note("<${reliquia} ~ ${final} ~>").s("triangle").slow(${p.repeticion > 0.15 ? 5 : 9}).gain(${decimal(0.04 + p.repeticion * 0.14)}).room(${decimal(0.55 + p.suspension * 0.28)}).delay(${decimal(0.10 + p.repeticion * 0.25)})`;
  const stack = (...xs: string[]) => `stack(\n  ${xs.filter(Boolean).join(",\n  ")}\n)`;

  const incubacion = stack(
    mel(mA, o1, p.vacio > 0.60 ? 12 : 9, 0.07 + p.densidad * 0.10, 0.58 + p.suspension * 0.28),
    eco,
  );

  const germinacion = stack(
    mel(mA, o1, p.suspension > 0.55 ? 8 : 6, 0.09 + p.densidad * 0.13, 0.42 + p.suspension * 0.26),
    sub(p.cuerpo > 0.55 ? 4 : 7, 0.06 + p.cuerpo * 0.16),
    p.pulso === "suspendido" ? "" : bd(0.08 + p.cuerpo * 0.18),
  );

  const formacion = stack(
    mel(mB, o2, p.repeticion > 0.15 ? 3 : 5, 0.10 + p.densidad * 0.16, 0.30 + p.suspension * 0.24),
    sub(p.repeticion > 0.15 ? 2 : 4, 0.09 + p.cuerpo * 0.22),
    bd(0.12 + p.cuerpo * 0.25),
    p.densidad > 0.40 ? hh(0.03 + p.fragmentacion * 0.10) : "",
  );

  const cuerpo = stack(
    mel(mB, o2, p.cuerpo > 0.60 ? 1 : 3, 0.09 + p.cuerpo * 0.20, 0.18 + p.suspension * 0.14),
    sub(p.pulso === "estable" ? 1 : 2, 0.13 + p.cuerpo * 0.28),
    bd(0.18 + p.cuerpo * 0.36),
    p.cuerpo > 0.38 ? cp : "",
    p.densidad > 0.48 ? hh(0.04 + p.fragmentacion * 0.10) : "",
  );

  const fractura = stack(
    mel(mC, "triangle", p.fragmentacion > 0.58 ? 2 : 5, 0.07 + p.fragmentacion * 0.15, 0.52 + p.suspension * 0.25),
    p.vacio > 0.64 ? "" : bd(0.09 + p.fragmentacion * 0.20, p.fragmentacion > 0.58 ? "bd(5,12)" : kick),
    p.fragmentacion > 0.38 ? hh(0.03 + p.fragmentacion * 0.10, "[~ hh]*8") : "",
  );

  const expansion = stack(
    p.repeticion > 0.15
      ? `note("<${reliquia} ${reliquia} ~ ${reliquia}>").s("${o2}").slow(2).gain(${decimal(0.06 + p.repeticion * 0.22)}).room(${decimal(0.36 + p.suspension * 0.24)})`
      : mel(mC, o1, 3, 0.11 + p.densidad * 0.17, 0.32 + p.suspension * 0.18),
    sub(p.cuerpo > 0.52 ? 1 : 3, 0.14 + p.cuerpo * 0.32),
    bd(0.20 + p.cuerpo * 0.38, p.repeticion > 0.15 ? "bd*4" : kick),
    p.cuerpo > 0.42 ? cp : "",
    p.densidad > 0.44 ? hh(0.04 + p.fragmentacion * 0.11, p.densidad > 0.62 ? "hh*16" : hats) : "",
    eco,
  );

  const memoria = stack(
    mel(mA, "sine", p.suspension > 0.55 ? 11 : 8, 0.06 + p.suspension * 0.08, 0.68 + p.suspension * 0.20),
    eco,
    p.repeticion > 0.28 ? bd(0.05 + p.cuerpo * 0.07, "bd ~ ~ ~") : "",
  );

  const pesos = [
    5 + p.vacio * 5,
    5 + p.suspension * 3,
    7 + p.densidad * 4,
    8 + p.cuerpo * 6,
    4 + p.fragmentacion * 5,
    7 + p.repeticion * 8 + p.cuerpo * 2,
    6 + p.suspension * 3,
  ];
  const total = pesos.reduce((s, x) => s + x, 0);
  const ciclos = pesos.map(x => Math.max(2, Math.floor((x / total) * CICLOS_COMPOSICION)));
  let dif = CICLOS_COMPOSICION - ciclos.reduce((s, x) => s + x, 0);
  let i = 0;
  while (dif > 0) { ciclos[i++ % ciclos.length] += 1; dif -= 1; }
  i = ciclos.length - 1;
  while (dif < 0) {
    const k = ((i % ciclos.length) + ciclos.length) % ciclos.length;
    if (ciclos[k] > 2) { ciclos[k] -= 1; dif += 1; }
    i -= 1;
  }

  return `/*\nORGANISMO · MOTOR COMPOSITIVO V5\n${organismo.codigo} · ${organismo.nombre}\nPulso: ${p.pulso}\nRepetición: ${Math.round(p.repeticion * 100)}\nFragmentación: ${Math.round(p.fragmentacion * 100)}\nSuspensión: ${Math.round(p.suspension * 100)}\nDensidad: ${Math.round(p.densidad * 100)}\nVacío: ${Math.round(p.vacio * 100)}\nCiclos: ${ciclos.join(" · ")}\n*/\n\nsetcpm(${bpm}/4)\n\nconst incubacion = ${incubacion}\nconst germinacion = ${germinacion}\nconst formacion = ${formacion}\nconst cuerpo = ${cuerpo}\nconst fractura = ${fractura}\nconst expansion = ${expansion}\nconst memoria = ${memoria}\n\narrange(\n  [${ciclos[0]}, incubacion],\n  [${ciclos[1]}, germinacion],\n  [${ciclos[2]}, formacion],\n  [${ciclos[3]}, cuerpo],\n  [${ciclos[4]}, fractura],\n  [${ciclos[5]}, expansion],\n  [${ciclos[6]}, memoria]\n)\n`;
}

export function urlStrudel(codigo: string): string {
  return `https://strudel.cc/#${base64Utf8(codigo)}`;
}
