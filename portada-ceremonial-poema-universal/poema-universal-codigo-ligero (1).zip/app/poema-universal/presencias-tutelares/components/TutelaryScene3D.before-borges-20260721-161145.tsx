"use client";

import {
  Canvas,
  useFrame,
} from "@react-three/fiber";

import {
  Float,
  Sparkles,
} from "@react-three/drei";

import {
  useMemo,
  useRef,
} from "react";

import type {
  Group,
  Mesh,
} from "three";

type TutelaryScene3DProps = {
  presenceId: string;
};

type PresenceWorld = {
  light: string;
  secondary: string;
  stone: string;
  fog: string;
};

const WORLDS: Record<
  string,
  PresenceWorld
> = {
  borges: {
    light: "#d6b96d",
    secondary: "#53698f",
    stone: "#b8aa91",
    fog: "#080b12",
  },

  pizarnik: {
    light: "#b59acb",
    secondary: "#655078",
    stone: "#c4b6c8",
    fog: "#0d0912",
  },

  camus: {
    light: "#efc66f",
    secondary: "#af8250",
    stone: "#d0b98d",
    fog: "#151007",
  },
};

function BorgesGuardian({
  world,
}: {
  world: PresenceWorld;
}) {
  const group =
    useRef<Group>(null);

  const head =
    useRef<Mesh>(null);

  useFrame(({ clock }) => {
    const time =
      clock.getElapsedTime();

    if (group.current) {
      group.current.rotation.y =
        Math.sin(time * 0.22) * 0.08;

      group.current.position.y =
        Math.sin(time * 0.45) * 0.035;
    }

    if (head.current) {
      head.current.rotation.z =
        -0.1 +
        Math.sin(time * 0.28) * 0.025;
    }
  });

  return (
    <group
      ref={group}
      position={[0, -1.15, 0]}
    >
      <mesh
        position={[0, 1.82, 0]}
        ref={head}
        rotation={[0.04, 0, -0.1]}
      >
        <sphereGeometry
          args={[0.43, 48, 48]}
        />

        <meshStandardMaterial
          color={world.stone}
          roughness={0.82}
          metalness={0.08}
        />
      </mesh>

      <mesh
        position={[0, 0.65, 0]}
        scale={[0.92, 1.45, 0.64]}
      >
        <capsuleGeometry
          args={[0.52, 1.15, 16, 32]}
        />

        <meshStandardMaterial
          color="#24262d"
          roughness={0.9}
        />
      </mesh>

      <mesh
        position={[-0.56, 0.58, 0]}
        rotation={[0, 0, -0.25]}
      >
        <capsuleGeometry
          args={[0.12, 1.1, 10, 20]}
        />

        <meshStandardMaterial
          color="#353740"
          roughness={0.88}
        />
      </mesh>

      <mesh
        position={[0.56, 0.58, 0]}
        rotation={[0, 0, 0.25]}
      >
        <capsuleGeometry
          args={[0.12, 1.1, 10, 20]}
        />

        <meshStandardMaterial
          color="#353740"
          roughness={0.88}
        />
      </mesh>

      <mesh
        position={[0.68, -0.08, 0.05]}
        rotation={[0, 0, -0.04]}
      >
        <cylinderGeometry
          args={[0.035, 0.05, 2.3, 18]}
        />

        <meshStandardMaterial
          color="#8f7045"
          roughness={0.72}
        />
      </mesh>

      <mesh
        position={[0, -0.55, 0.3]}
        rotation={[-0.32, 0, 0]}
      >
        <boxGeometry
          args={[0.76, 0.08, 0.5]}
        />

        <meshStandardMaterial
          color="#725b3c"
          roughness={0.9}
        />
      </mesh>

      <mesh
        position={[-0.2, 1.86, 0.37]}
        scale={[0.14, 0.035, 0.025]}
      >
        <sphereGeometry
          args={[1, 24, 24]}
        />

        <meshStandardMaterial
          color="#111217"
          emissive="#111217"
        />
      </mesh>

      <mesh
        position={[0.2, 1.86, 0.37]}
        scale={[0.14, 0.035, 0.025]}
      >
        <sphereGeometry
          args={[1, 24, 24]}
        />

        <meshStandardMaterial
          color="#111217"
          emissive="#111217"
        />
      </mesh>
    </group>
  );
}

function PizarnikGuardian({
  world,
}: {
  world: PresenceWorld;
}) {
  const group =
    useRef<Group>(null);

  useFrame(({ clock }) => {
    const time =
      clock.getElapsedTime();

    if (group.current) {
      group.current.rotation.y =
        Math.sin(time * 0.18) * 0.12;

      group.current.position.y =
        Math.sin(time * 0.35) * 0.05;
    }
  });

  return (
    <group
      ref={group}
      position={[0, -1.1, 0]}
    >
      <mesh
        position={[0, 1.7, 0]}
        scale={[0.9, 1.05, 0.86]}
      >
        <sphereGeometry
          args={[0.4, 48, 48]}
        />

        <meshStandardMaterial
          color={world.stone}
          roughness={0.88}
        />
      </mesh>

      <mesh
        position={[0, 0.38, 0]}
        scale={[1.08, 1.8, 0.7]}
      >
        <coneGeometry
          args={[0.72, 2.4, 48]}
        />

        <meshStandardMaterial
          color="#211a2a"
          roughness={0.94}
        />
      </mesh>

      <mesh
        position={[0, 0.72, 0.52]}
      >
        <sphereGeometry
          args={[0.08, 24, 24]}
        />

        <meshStandardMaterial
          color={world.light}
          emissive={world.light}
          emissiveIntensity={2.5}
        />
      </mesh>

      <mesh
        position={[-0.56, 1.78, 0.08]}
        rotation={[0, 0, -0.35]}
      >
        <torusGeometry
          args={[0.34, 0.07, 18, 48, 3.8]}
        />

        <meshStandardMaterial
          color="#17131c"
          roughness={0.95}
        />
      </mesh>
    </group>
  );
}

function CamusGuardian({
  world,
}: {
  world: PresenceWorld;
}) {
  const group =
    useRef<Group>(null);

  useFrame(({ clock }) => {
    const time =
      clock.getElapsedTime();

    if (group.current) {
      group.current.rotation.y =
        Math.sin(time * 0.2) * 0.07;

      group.current.position.y =
        Math.sin(time * 0.4) * 0.025;
    }
  });

  return (
    <group
      ref={group}
      position={[0, -1.15, 0]}
    >
      <mesh
        position={[0, 1.78, 0]}
      >
        <sphereGeometry
          args={[0.42, 48, 48]}
        />

        <meshStandardMaterial
          color={world.stone}
          roughness={0.78}
        />
      </mesh>

      <mesh
        position={[0, 0.58, 0]}
        scale={[0.95, 1.55, 0.68]}
      >
        <capsuleGeometry
          args={[0.52, 1.3, 16, 32]}
        />

        <meshStandardMaterial
          color="#403326"
          roughness={0.88}
        />
      </mesh>

      <mesh
        position={[0, -0.66, 0.08]}
        rotation={[0.06, 0, 0]}
      >
        <dodecahedronGeometry
          args={[0.56, 0]}
        />

        <meshStandardMaterial
          color="#b99b65"
          roughness={1}
        />
      </mesh>

      <mesh
        position={[0.7, 1.8, -0.35]}
      >
        <sphereGeometry
          args={[0.24, 32, 32]}
        />

        <meshStandardMaterial
          color={world.light}
          emissive={world.light}
          emissiveIntensity={3}
        />
      </mesh>
    </group>
  );
}

function Guardian({
  presenceId,
  world,
}: TutelaryScene3DProps & {
  world: PresenceWorld;
}) {
  if (presenceId === "pizarnik") {
    return (
      <PizarnikGuardian
        world={world}
      />
    );
  }

  if (presenceId === "camus") {
    return (
      <CamusGuardian
        world={world}
      />
    );
  }

  return (
    <BorgesGuardian
      world={world}
    />
  );
}

function Scene({
  presenceId,
}: TutelaryScene3DProps) {
  const world =
    WORLDS[presenceId] ??
    WORLDS.borges;

  const sparkles = useMemo(
    () =>
      presenceId === "pizarnik"
        ? 42
        : presenceId === "camus"
          ? 22
          : 34,
    [presenceId]
  );

  return (
    <>
      <color
        attach="background"
        args={[world.fog]}
      />

      <fog
        attach="fog"
        args={[world.fog, 4, 10]}
      />

      <ambientLight
        intensity={0.62}
      />

      <directionalLight
        position={[3, 4, 4]}
        intensity={2.4}
        color={world.light}
      />

      <pointLight
        position={[-2.5, 1.5, 2]}
        intensity={2.2}
        color={world.secondary}
      />

      <pointLight
        position={[0, -0.5, 2.8]}
        intensity={0.75}
        color={world.light}
      />

      <Sparkles
        count={sparkles}
        scale={[4.5, 5.5, 3]}
        size={1.8}
        speed={0.16}
        color={world.light}
        opacity={0.56}
      />

      <Float
        speed={0.7}
        rotationIntensity={0.08}
        floatIntensity={0.12}
      >
        <Guardian
          presenceId={presenceId}
          world={world}
        />
      </Float>

      <mesh
        position={[0, -2.26, 0]}
        rotation={[-Math.PI / 2, 0, 0]}
      >
        <circleGeometry
          args={[1.45, 64]}
        />

        <meshStandardMaterial
          color="#131419"
          roughness={0.96}
          metalness={0.08}
        />
      </mesh>
    </>
  );
}

export default function
TutelaryScene3D({
  presenceId,
}: TutelaryScene3DProps) {
  return (
    <div
      aria-label="Presencia tutelar tridimensional"
      role="img"
      style={{
        width: "100%",
        height: "100%",
        minHeight: 430,
      }}
    >
      <Canvas
        camera={{
          position: [0, 0.3, 5.8],
          fov: 38,
        }}
        dpr={[1, 1.7]}
        gl={{
          antialias: true,
          alpha: false,
          powerPreference:
            "high-performance",
        }}
      >
        <Scene
          presenceId={presenceId}
        />
      </Canvas>
    </div>
  );
}
