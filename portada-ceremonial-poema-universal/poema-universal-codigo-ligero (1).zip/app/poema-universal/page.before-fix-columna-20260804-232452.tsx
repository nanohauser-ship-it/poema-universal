"use client";

import Link from "next/link";
import { useEffect, useState } from "react";

import WorldGlobeLive from "./components/WorldGlobeLive";
import SupportersSection from "./components/SupportersSection";
import PoetProfilePanel, {
  type PoetProfile,
} from "./components/PoetProfilePanel";
import PoetPresence from "./components/PoetPresence";
import AvatarRelicStudio from "./components/AvatarRelicStudio";

import WorldEntrance from "./components/WorldEntrance";
import MatrizEntrance from "./components/MatrizEntrance";
import BorgesEntrance from "./components/BorgesEntrance";
import AtlasInteriorEntrance from "./components/AtlasInteriorEntrance";
import BestiarioEntrance from "./components/BestiarioEntrance";

import ThreePresencesEntrance
  from "./components/ThreePresencesEntrance";

const PRESENTATION_DATE = new Date(
  "2027-01-01T00:00:00+01:00"
).getTime();

const TOTAL_VOICES = 60;
const INCORPORATION_VOICES = 4;

type CountdownTime = {
  dias: number;
  horas: number;
  minutos: number;
  segundos: number;
};

type VoiceSlot = {
  position: number;
  status: "incorporation" | "available";
};

const voiceSlots: VoiceSlot[] = Array.from(
  { length: TOTAL_VOICES },
  (_, index) => ({
    position: index + 1,
    status:
      index < INCORPORATION_VOICES
        ? "incorporation"
        : "available",
  })
);




type PublicPoetApi = {
  id: string;
  position: number;
  name: string;
  country: string;
  countryCode: string | null;
  city: string | null;
  shortBio: string;
  portraitUrl: string | null;
  status: "confirmed" | "published";
  profileSlug: string | null;
};

type PublicPoetsResponse = {
  editionYear: number;
  poets: PublicPoetApi[];
};

const manifestoPrinciples = [
  {
    number: "I",
    title: "Una sola obra",
    text: "Cada fragmento conservará su identidad, pero deberá servir a la arquitectura completa del poema.",
  },
  {
    number: "II",
    title: "Sesenta voces",
    text: "Ninguna voz ocupará una posición superior. Todas compartirán el mismo espacio editorial.",
  },
  {
    number: "III",
    title: "Un año de escritura",
    text: "La obra crecerá durante 2026 y permanecerá cerrada hasta su presentación pública.",
  },
  {
    number: "IV",
    title: "Una memoria común",
    text: "El libro conservará aquello que el mundo haya dejado escrito en las personas que lo habitaron.",
  },
];

const navigationLinks = [
  {
    label: "Manifiesto",
    href: "#manifiesto",
  },
  {
    label: "Las voces",
    href: "#voces",
  },
  {
    label: "El mundo",
    href: "#mundo",
  },
  {
    label: "Bestiario",
    href: "/poema-universal/bestiario-poetico",
  },
  {
    label: "El coro",
    href: "/poema-universal/coro-de-la-tierra",
  },
  {
    label: "Convocatoria",
    href: "/poema-universal/convocatoria",
  },
  {\n    label: "Columna de las voces",\n    href: "/poema-universal/encadenamiento",\n  },\n];

function calculateCountdown(): CountdownTime {
  const difference =
    PRESENTATION_DATE - Date.now();

  if (difference <= 0) {
    return {
      dias: 0,
      horas: 0,
      minutos: 0,
      segundos: 0,
    };
  }

  return {
    dias: Math.floor(
      difference / (1000 * 60 * 60 * 24)
    ),
    horas: Math.floor(
      (difference / (1000 * 60 * 60)) % 24
    ),
    minutos: Math.floor(
      (difference / (1000 * 60)) % 60
    ),
    segundos: Math.floor(
      (difference / 1000) % 60
    ),
  };
}

export default function PoemaUniversalPage() {
  const [selectedPoet, setSelectedPoet] =
    useState<PoetProfile | null>(null);

  const [poetProfiles, setPoetProfiles] =
    useState<Record<number, PoetProfile>>({});

  const [time, setTime] =
    useState<CountdownTime>({
      dias: 0,
      horas: 0,
      minutos: 0,
      segundos: 0,
    });

  useEffect(() => {
    setTime(calculateCountdown());

    const interval = window.setInterval(() => {
      setTime(calculateCountdown());
    }, 1000);

    return () => {
      window.clearInterval(interval);
    };
  }, []);

  useEffect(() => {
    let cancelled = false;

    async function loadPublicPoets() {
      try {
        const response = await fetch(
          "/api/poema-universal/poets",
          {
            cache: "no-store",
          }
        );

        if (!response.ok) {
          throw new Error(
            `Error ${response.status} al cargar los perfiles.`
          );
        }

        const data =
          (await response.json()) as PublicPoetsResponse;

        if (cancelled) {
          return;
        }

        const profilesByPosition: Record<
          number,
          PoetProfile
        > = {};

        for (const poet of data.poets) {
          profilesByPosition[poet.position] = {
            position: poet.position,
            name: poet.name,
            country: poet.country,
            ...(poet.city
              ? {
                  city: poet.city,
                }
              : {}),
            shortBio: poet.shortBio,
            status:
              poet.status === "published"
                ? "published"
                : "confirmed",
          };
        }

        setPoetProfiles(profilesByPosition);
      } catch (error) {
        console.error(
          "No se pudieron cargar los perfiles públicos:",
          error
        );
      }
    }

    loadPublicPoets();

    return () => {
      cancelled = true;
    };
  }, []);

  const countdownItems = [
    {
      value: time.dias,
      label: "Días",
    },
    {
      value: time.horas,
      label: "Horas",
    },
    {
      value: time.minutos,
      label: "Minutos",
    },
    {
      value: time.segundos,
      label: "Segundos",
    },
  ];

  const availableVoices =
    TOTAL_VOICES - INCORPORATION_VOICES;

  return (
    <main
      id="top"
      className="min-h-screen overflow-x-hidden"
      style={{
        backgroundColor: "#f0e8dc",
        color: "#171411",
      }}
    >
      {/* NAVEGACIÓN */}

      <header
        className="sticky top-0 z-50 border-b backdrop-blur-xl"
        style={{
          borderColor: "rgba(23,20,17,0.12)",
          backgroundColor:
            "rgba(240,232,220,0.94)",
        }}
      >
        <div className="mx-auto flex min-h-[70px] max-w-[1380px] items-center justify-between gap-8 px-5 sm:px-8 lg:px-12">
          <Link
            href="/poema-universal"
            className="font-serif text-xl tracking-[-0.025em] transition hover:opacity-55"
          >
            Poema Universal
          </Link>

          <nav
            aria-label="Navegación de Poema Universal"
            className="hidden items-center gap-10 md:flex"
          >
            {navigationLinks.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className="text-[9px] uppercase tracking-[0.31em] text-stone-500 transition hover:text-stone-950"
              >
                {link.label}
              </Link>
            ))}
          </nav>

          <div className="flex items-center gap-5">
            <span className="hidden text-[8px] uppercase tracking-[0.3em] text-stone-400 lg:block">
              Edición fundacional · 2026
            </span>

            <Link
              href="/"
              className="border border-stone-900/20 px-5 py-2.5 text-[8px] uppercase tracking-[0.3em] transition hover:bg-[#171411] hover:text-white"
            >
              Inicio
            </Link>
          </div>
        </div>
      </header>

      {/* PASO DESDE LA HOME */}

      <section
        id="entrada"
        aria-label="Entrada a la sala universal"
        className="relative scroll-mt-[70px] overflow-hidden"
        style={{
          background:
            "linear-gradient(180deg, #f0e8dc 0%, #f3ece2 58%, #f0e8dc 100%)",
        }}
      >
        <div
          aria-hidden="true"
          className="pointer-events-none absolute left-1/2 top-0 h-full w-[720px] -translate-x-1/2"
          style={{
            background:
              "radial-gradient(circle at 50% 42%, rgba(255,255,255,0.72), transparent 54%)",
          }}
        />

        <div className="relative mx-auto grid min-h-[116px] max-w-[1380px] items-center gap-6 px-5 pb-12 pt-6 sm:px-8 md:grid-cols-[1fr_auto_1fr] lg:px-12">
          <Link
            href="/"
            className="justify-self-center text-[8px] uppercase tracking-[0.3em] text-stone-500 transition hover:text-stone-950 md:justify-self-start"
          >
            ← Volver a la casa
          </Link>

          <div className="flex items-center justify-center gap-4">
            <span
              aria-hidden="true"
              className="hidden h-px w-20 sm:block"
              style={{
                background:
                  "linear-gradient(to right, transparent, rgba(199,164,103,0.62))",
              }}
            />

            <span
              aria-hidden="true"
              className="h-2 w-2 rounded-full"
              style={{
                backgroundColor: "#c7a467",
                boxShadow:
                  "0 0 20px rgba(199,164,103,0.5)",
              }}
            />

            <p
              className="font-serif text-base italic sm:text-lg"
              style={{
                color: "rgba(23,20,17,0.66)",
              }}
            >
              Has cruzado el umbral.
            </p>

            <span
              aria-hidden="true"
              className="hidden h-px w-20 sm:block"
              style={{
                background:
                  "linear-gradient(to left, transparent, rgba(199,164,103,0.62))",
              }}
            />
          </div>

          <p className="justify-self-center text-[8px] uppercase tracking-[0.3em] text-stone-400 md:justify-self-end">
            60 voces · un solo libro
          </p>
        </div>

        <span
          aria-hidden="true"
          className="absolute bottom-0 left-1/2 h-12 w-px -translate-x-1/2"
          style={{
            background:
              "linear-gradient(to bottom, rgba(199,164,103,0.72), rgba(199,164,103,0.08))",
          }}
        />
      </section>

      {/* 01 · UMBRAL */}

      <section className="relative -mt-px overflow-hidden">
        <div
          aria-hidden="true"
          className="pointer-events-none absolute left-1/2 top-[-360px] h-[900px] w-[1100px] -translate-x-1/2 rounded-full blur-[170px]"
          style={{
            background:
              "radial-gradient(circle, rgba(255,255,255,0.86) 0%, rgba(255,255,255,0.42) 46%, transparent 72%)",
          }}
        />

        <span
          aria-hidden="true"
          className="pointer-events-none absolute left-1/2 top-0 h-24 w-px -translate-x-1/2"
          style={{
            background:
              "linear-gradient(to bottom, rgba(199,164,103,0.42), transparent)",
          }}
        />

        <div className="relative mx-auto max-w-[1380px] px-5 sm:px-8 lg:px-12">
          <div className="flex items-center justify-between pt-12">
            <p className="text-[8px] uppercase tracking-[0.4em] text-stone-500">
              Institución literaria internacional
            </p>

            <p className="text-[8px] uppercase tracking-[0.3em] text-stone-400">
              Presentación · 01.01.2027
            </p>
          </div>

          <div className="flex min-h-[620px] flex-col items-center justify-center pb-24 pt-16 text-center sm:min-h-[690px] sm:pb-28 sm:pt-20">
            <p
              className="text-[9px] uppercase tracking-[0.52em]"
              style={{
                color: "#9a743e",
              }}
            >
              Edición fundacional
            </p>

            <h1 className="mt-9 font-serif text-7xl leading-[0.84] tracking-[-0.065em] sm:text-9xl lg:text-[142px]">
              Poema
              <span className="block italic text-stone-500">
                Universal
              </span>
            </h1>

            <p className="mx-auto mt-12 max-w-3xl font-serif text-2xl italic leading-[1.5] text-stone-600 sm:text-3xl lg:text-[38px]">
              Una única obra escrita durante un año
              por sesenta voces del mundo.
            </p>

            <Link
              href="#manifiesto"
              className="mt-14 border-b border-stone-900/25 pb-2 text-[8px] uppercase tracking-[0.35em] text-stone-500 transition hover:border-stone-950 hover:text-stone-950"
            >
              Leer la declaración fundacional ↓
            </Link>
          </div>

          {/* CUENTA ATRÁS */}

          <div className="border-t border-stone-900/15 pb-16 pt-8">
            <div className="mb-7 flex items-center justify-between">
              <p className="text-[8px] uppercase tracking-[0.36em] text-stone-500">
                Tiempo restante
              </p>

              <p className="text-[8px] uppercase tracking-[0.3em] text-stone-400">
                Apertura del primer libro
              </p>
            </div>

            <div className="grid grid-cols-2 border-l border-t border-stone-900/15 sm:grid-cols-4">
              {countdownItems.map((item) => (
                <div
                  key={item.label}
                  className="border-b border-r border-stone-900/15 px-6 py-7 sm:px-8 sm:py-9"
                >
                  <span className="block font-serif text-5xl tracking-[-0.055em] sm:text-6xl lg:text-7xl">
                    {String(item.value).padStart(
                      2,
                      "0"
                    )}
                  </span>

                  <span className="mt-4 block text-[8px] uppercase tracking-[0.32em] text-stone-500">
                    {item.label}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* 02 · MANIFIESTO */}

      <section
        id="manifiesto"
        className="border-t border-stone-900/15"
      >
        <div className="mx-auto max-w-[1380px] px-5 py-28 sm:px-8 sm:py-36 lg:px-12 lg:py-44">
          <div className="grid gap-14 lg:grid-cols-[1.1fr_0.9fr] lg:gap-28">
            <div>
              <p
                className="text-[9px] uppercase tracking-[0.48em]"
                style={{
                  color: "#9a743e",
                }}
              >
                Manifiesto universal
              </p>

              <h2 className="mt-9 max-w-4xl font-serif text-5xl leading-[1.02] tracking-[-0.048em] sm:text-7xl lg:text-[88px]">
                No reunimos poemas.
                <span className="mt-2 block italic text-stone-500">
                  Escribimos un año.
                </span>
              </h2>
            </div>

            <div className="flex flex-col justify-end">
              <p className="font-serif text-2xl italic leading-[1.55] text-stone-700 sm:text-3xl">
                Poema Universal nace para reunir
                sensibilidades distintas dentro de una
                misma construcción literaria.
              </p>

              <p className="mt-8 max-w-xl text-base leading-8 text-stone-600">
                No será una antología ni una colección
                de nombres. Será una única obra,
                construida lentamente durante todo un
                año y custodiada como memoria de su
                tiempo.
              </p>
            </div>
          </div>

          <div className="mt-24 border-t border-stone-900/15">
            {manifestoPrinciples.map(
              (principle) => (
                <article
                  key={principle.number}
                  className="grid gap-5 border-b border-stone-900/15 py-8 md:grid-cols-[80px_250px_1fr] md:items-start"
                >
                  <span
                    className="font-serif text-lg italic"
                    style={{
                      color: "#a37c44",
                    }}
                  >
                    {principle.number}
                  </span>

                  <h3 className="font-serif text-2xl">
                    {principle.title}
                  </h3>

                  <p className="max-w-2xl text-sm leading-7 text-stone-600 sm:text-base sm:leading-8">
                    {principle.text}
                  </p>
                </article>
              )
            )}
          </div>

          <blockquote className="mx-auto mt-24 max-w-5xl text-center">
            <p className="font-serif text-3xl italic leading-[1.5] text-stone-700 sm:text-5xl">
              “Mientras exista una voz que todavía no
              haya encontrado su lugar, el poema no
              estará terminado.”
            </p>

            <footer className="mt-9 text-[8px] uppercase tracking-[0.4em] text-stone-400">
              Declaración fundacional
            </footer>
          </blockquote>
        </div>
      </section>

      {/* NOCHE INSTITUCIONAL */}

      <section
        style={{
          backgroundColor: "#060a0e",
          color: "#f0e8dc",
        }}
      >
        {/* 03 · LAS VOCES */}

        <div
          id="voces"
          className="mx-auto max-w-[1380px] px-5 py-20 sm:px-8 sm:py-24 lg:px-12 lg:py-28"
        >
          <div className="grid gap-14 lg:grid-cols-[1fr_0.8fr] lg:gap-24">
            <div>
              <p
                className="text-[9px] uppercase tracking-[0.46em]"
                style={{
                  color: "#c7a467",
                }}
              >
                Registro de la edición
              </p>

              <h2
                className="mt-8 font-serif text-5xl leading-[0.98] tracking-[-0.05em] sm:text-7xl lg:text-[88px]"
                style={{
                  color: "#f0e8dc",
                }}
              >
                Sesenta voces.
                <span
                  className="block italic"
                  style={{
                    color:
                      "rgba(240,232,220,0.58)",
                  }}
                >
                  Un mismo lugar.
                </span>
              </h2>
            </div>

            <div className="flex flex-col justify-end">
              <p
                className="font-serif text-2xl italic leading-[1.55] sm:text-3xl"
                style={{
                  color:
                    "rgba(240,232,220,0.78)",
                }}
              >
                Las identidades aparecerán cuando su
                participación haya sido confirmada.
              </p>

              <div className="mt-10 flex gap-12">
                <div>
                  <span className="block font-serif text-4xl">
                    {INCORPORATION_VOICES}
                  </span>

                  <span
                    className="mt-2 block text-[8px] uppercase tracking-[0.28em]"
                    style={{
                      color:
                        "rgba(240,232,220,0.58)",
                    }}
                  >
                    En incorporación
                  </span>
                </div>

                <div>
                  <span className="block font-serif text-4xl">
                    {availableVoices}
                  </span>

                  <span
                    className="mt-2 block text-[8px] uppercase tracking-[0.28em]"
                    style={{
                      color:
                        "rgba(240,232,220,0.58)",
                    }}
                  >
                    Disponibles
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* RETÍCULA */}

          <div className="mt-20 flex flex-col gap-8 border-y border-white/[0.12] py-9 sm:flex-row sm:items-end sm:justify-between">
            <p
              className="max-w-2xl font-serif text-2xl leading-[1.12] tracking-[-0.025em] sm:text-3xl"
              style={{ color: "#f0e8dc" }}
            >
              Aquí nadie entra por su nombre.
              <span
                className="block italic"
                style={{
                  color: "rgba(240,232,220,0.54)",
                }}
              >
                Entra por su voz.
              </span>
            </p>

            <p
              className="text-[8px] uppercase tracking-[0.34em]"
              style={{
                color: "rgba(240,232,220,0.46)",
              }}
            >
              60 voces · una misma dignidad
            </p>
          </div>

          <ol className="mt-10 grid grid-cols-2 border-l border-t border-white/[0.16] sm:grid-cols-3 lg:grid-cols-6">
            {voiceSlots.map((slot) => {
              const isIncorporation =
                slot.status === "incorporation";

              const poetProfile =
                poetProfiles[slot.position] ?? null;

              const isPublicVoice =
                Boolean(poetProfile);

              const voiceLabel = poetProfile
                ? poetProfile.name
                : isIncorporation
                  ? "Voz en incorporación"
                  : "Voz por llegar";

              const territoryLabel = poetProfile
                ? [
                    poetProfile.country,
                    poetProfile.city,
                  ]
                    .filter(Boolean)
                    .join(" · ")
                : isIncorporation
                  ? "Identidad protegida"
                  : "Plaza abierta";

              const footerLabel = poetProfile
                ? "Abrir ficha →"
                : isIncorporation
                  ? "Edición fundacional 2026"
                  : "Poema Universal 2026";
              return (
                <PoetPresence
                  key={slot.position}
                  position={slot.position}
                  state={
                    isPublicVoice
                      ? "public"
                      : isIncorporation
                        ? "incorporation"
                        : "open"
                  }
                  name={voiceLabel}
                  territory={territoryLabel}
                  footer={footerLabel}
                  onOpen={
                    poetProfile
                      ? () =>
                          setSelectedPoet(
                            poetProfile
                          )
                      : undefined
                  }
                />
              );

            })}
          </ol>

          <PoetProfilePanel
            poet={selectedPoet}
            onClose={() => setSelectedPoet(null)}
          />

          <AvatarRelicStudio />
        </div>

        {/* 04 · EL MUNDO */}

        <div className="border-t border-white/10">
          <div className="mx-auto max-w-[1380px] px-5 pt-16 text-center sm:px-8 sm:pt-20 lg:px-12">
            <p
              className="text-[9px] uppercase tracking-[0.46em]"
              style={{
                color: "#c7a467",
              }}
            >
              Cartografía de una voz común
            </p>

            <h2
              className="mx-auto mt-8 max-w-5xl font-serif text-5xl leading-[0.98] tracking-[-0.05em] sm:text-7xl lg:text-[88px]"
              style={{
                color: "#f0e8dc",
              }}
            >
              El mundo comienza
              <span
                className="block italic"
                style={{
                  color:
                    "rgba(240,232,220,0.58)",
                }}
              >
                a escribir junto.
              </span>
            </h2>

            <p
              className="mx-auto mt-9 max-w-2xl text-sm leading-7 sm:text-base sm:leading-8"
              style={{
                color:
                  "rgba(240,232,220,0.58)",
              }}
            >
              Cada territorio iluminado representa una
              presencia que comienza a formar parte de
              la edición fundacional.
            </p>
          </div>

          <WorldGlobeLive />
        </div>

        {/* CIERRE MÍNIMO */}

        <footer className="mx-auto max-w-[1380px] border-t border-white/10 px-5 py-10 sm:px-8 lg:px-12">
          <div className="flex flex-col items-center justify-between gap-6 text-center sm:flex-row sm:text-left">
            <p
              className="text-[8px] uppercase tracking-[0.3em]"
              style={{
                color:
                  "rgba(240,232,220,0.25)",
              }}
            >
              © 2026 Poema Universal
            </p>

            <p
              className="text-[8px] uppercase tracking-[0.3em]"
              style={{
                color: "#c7a467",
              }}
            >
              Fundador y poeta · José Naveiro
            </p>

            <Link
              href="#top"
              className="text-[8px] uppercase tracking-[0.3em] transition hover:opacity-60"
              style={{
                color:
                  "rgba(240,232,220,0.34)",
              }}
            >
              Volver al inicio ↑
            </Link>
          </div>
        </footer>
      </section>
      <SupportersSection />
          <WorldEntrance />

          <MatrizEntrance />

      <BestiarioEntrance />

      <ThreePresencesEntrance />

      <BorgesEntrance />

      <AtlasInteriorEntrance />
</main>
  );
}
