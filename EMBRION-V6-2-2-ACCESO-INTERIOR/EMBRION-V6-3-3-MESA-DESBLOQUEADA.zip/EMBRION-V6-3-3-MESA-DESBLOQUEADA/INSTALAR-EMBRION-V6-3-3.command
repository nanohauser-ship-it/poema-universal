#!/bin/bash
set -euo pipefail
ROOT="${1:-$HOME/poema-universal}"
HERE="$(cd "$(dirname "$0")" && pwd)"
PAYLOAD="$HERE/PAYLOAD"
STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP="$ROOT/.embrion-backups/v6-3-3-mesa-$STAMP"

echo "===== EMBRIÓN V6.3.3 · MESA DESBLOQUEADA ====="
[ -d "$ROOT/app/laboratorio/verso-tecno" ] || { echo "❌ No encuentro $ROOT/app/laboratorio/verso-tecno"; exit 1; }
mkdir -p "$BACKUP/app/laboratorio/verso-tecno/organismo"
cp -f "$ROOT/app/laboratorio/verso-tecno/organismo/WordArchive.tsx" "$BACKUP/app/laboratorio/verso-tecno/organismo/WordArchive.tsx" 2>/dev/null || true
cp -f "$ROOT/app/laboratorio/verso-tecno/organismo-v47.module.css" "$BACKUP/app/laboratorio/verso-tecno/organismo-v47.module.css" 2>/dev/null || true
cp -f "$PAYLOAD/app/laboratorio/verso-tecno/organismo/WordArchive.tsx" "$ROOT/app/laboratorio/verso-tecno/organismo/WordArchive.tsx"
cp -f "$PAYLOAD/app/laboratorio/verso-tecno/organismo-v47.module.css" "$ROOT/app/laboratorio/verso-tecno/organismo-v47.module.css"
echo "✅ Mesa de Montaje desbloqueada."
echo "✅ Selector directo dentro de la Mesa."
echo "✅ Modo Montaje: pulsar palabras de la Membrana las añade directamente."
echo "✅ Membrana, ciclos y libreta no se modifican."
echo "✅ Backup: $BACKUP"
