#!/bin/bash
set -euo pipefail

source_dir="$(cd "$(dirname "$0")" && pwd)"
target_dir="${1:-$HOME/poema-universal}"
payload="$source_dir/PAYLOAD"
ts="$(date +%Y%m%d-%H%M%S)"
backup="$target_dir/backups/embrion-v6-3-2-ciclos-membrana-$ts"

files=(
  "app/laboratorio/verso-tecno/OrganismoV47.tsx"
  "app/laboratorio/verso-tecno/organismo-v47.module.css"
  "app/laboratorio/verso-tecno/organismo/WordArchive.tsx"
  "app/laboratorio/verso-tecno/organismo/SymbolicImpulseConsole.tsx"
  "app/laboratorio/verso-tecno/organismo/LiteraryNotebook.tsx"
)

echo ""
echo "EMBRIÓN V6.3.2 · CICLOS DE LA MEMBRANA"
echo "========================================="

if [[ ! -f "$target_dir/package.json" ]]; then
  echo "❌ No encuentro Poema Universal en $target_dir"
  exit 1
fi

base="$target_dir/app/laboratorio/verso-tecno/OrganismoV47.tsx"
if [[ ! -f "$base" ]]; then
  echo "❌ No encuentro OrganismoV47.tsx"
  exit 1
fi

if ! grep -q 'V6.2.2 · ACCESO INTERIOR' "$base"; then
  echo "❌ Este instalador necesita como mínimo Embrión V6.2.2."
  exit 1
fi

mkdir -p "$backup"
for file in "${files[@]}"; do
  if [[ -f "$target_dir/$file" ]]; then
    mkdir -p "$backup/$(dirname "$file")"
    cp -p "$target_dir/$file" "$backup/$file"
  fi
  mkdir -p "$target_dir/$(dirname "$file")"
  cp -p "$payload/$file" "$target_dir/$file"
done

if ! grep -q 'V6.3.2 · MEMBRANA PODABLE' "$target_dir/app/laboratorio/verso-tecno/OrganismoV47.tsx"; then
  echo "❌ No se pudo verificar la lógica V6.3.2."
  exit 1
fi

if ! grep -q 'ARCHIVO DE CICLOS' "$target_dir/app/laboratorio/verso-tecno/organismo/WordArchive.tsx"; then
  echo "❌ No se pudo verificar el Archivo de Ciclos."
  exit 1
fi

if ! grep -q 'MÁRGENES VIVOS' "$target_dir/app/laboratorio/verso-tecno/organismo/LiteraryNotebook.tsx"; then
  echo "❌ No se preservaron los Márgenes Vivos de la Libreta."
  exit 1
fi

if ! grep -q 'MEMBRANA PODABLE + ARCHIVO DE CICLOS' "$target_dir/app/laboratorio/verso-tecno/organismo-v47.module.css"; then
  echo "❌ No se pudo verificar el estilo de gestión de Membrana."
  exit 1
fi

echo "✓ Poda individual ×"
echo "✓ Selección múltiple ○ + PODAR SELECCIÓN"
echo "✓ Vaciado total con confirmación en dos pasos"
echo "✓ ARCHIVAR CICLO crea una copia antes de limpiar"
echo "✓ Archivo de Ciclos persistente en localStorage"
echo "✓ Restauración de cualquier ciclo"
echo "✓ Exportación CSV de la Membrana actual y de cada ciclo"
echo "✓ Comparador entre dos ciclos con formas comunes y exclusivas"
echo "✓ Mesa de Montaje y selección de poda permanecen separadas"
echo "✓ Libreta V6.3.1 + Márgenes Vivos preservados"
echo "✓ La Membrana actual existente NO se borra al instalar"
echo ""
echo "✅ EMBRIÓN V6.3.2 INSTALADO"
echo "Backup: $backup"
echo ""
echo "Reinicia Next.js y abre:"
echo "http://localhost:3000/laboratorio/verso-tecno"
