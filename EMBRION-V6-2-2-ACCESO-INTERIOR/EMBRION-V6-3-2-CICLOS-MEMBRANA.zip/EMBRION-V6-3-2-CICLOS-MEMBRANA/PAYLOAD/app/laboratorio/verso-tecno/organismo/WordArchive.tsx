"use client";

import { useEffect, useMemo, useState } from "react";
import type {
  EvidenceState,
  ImpulseKind,
  SymbolicHabitat,
  SymbolicImpulse,
} from "@/lib/embrion/symbolic-engine";
import styles from "../organismo-v47.module.css";

export type ArchivedWord = {
  id: string;
  value: string;
  kind: ImpulseKind;
  habitat: SymbolicHabitat;
  nucleus: string;
  nuclei: string[];
  evidence: EvidenceState;
  confidence: number;
  sourceLabels: string[];
  appearances: number;
  firstSeenAt: number;
  lastSeenAt: number;
};

export type MembraneCycle = {
  id: string;
  name: string;
  archivedAt: number;
  entries: ArchivedWord[];
  totalAppearances: number;
  sourceLabels: string[];
};

type Props = {
  entries: ArchivedWord[];
  cycles: MembraneCycle[];
  savedImpulses: SymbolicImpulse[];
  onRecall: (entry: ArchivedWord) => void;
  onAssemble: (entries: ArchivedWord[]) => void;
  onPrune: (ids: string[]) => void;
  onArchiveCycle: (name: string) => void;
  onRestoreCycle: (cycle: MembraneCycle) => void;
};

const STRATA: Array<{ kind: ImpulseKind; label: string; number: string }> = [
  { kind: "palabra", label: "PALABRAS", number: "01" },
  { kind: "símbolo", label: "SÍMBOLOS", number: "02" },
  { kind: "imagen", label: "IMÁGENES", number: "03" },
  { kind: "materia", label: "MATERIAS", number: "04" },
  { kind: "verbo", label: "VERBOS", number: "05" },
  { kind: "tensión", label: "TENSIONES", number: "06" },
];

function archiveKey(kind: ImpulseKind, value: string): string {
  return `${kind}:${value
    .toLocaleLowerCase("es")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-zñ0-9]+/g, "-")}`;
}

function escapeCsv(value: string | number): string {
  const text = String(value ?? "");
  return `"${text.replace(/"/g, '""')}"`;
}

function cycleDate(timestamp: number): string {
  return new Intl.DateTimeFormat("es-ES", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  }).format(new Date(timestamp));
}

function downloadEntries(entries: ArchivedWord[], filename: string) {
  const rows = [
    ["forma", "tipo", "habitat", "evidencia", "fuerza", "apariciones", "nucleos", "fuentes"],
    ...entries.map((entry) => [
      entry.value,
      entry.kind,
      entry.habitat,
      entry.evidence,
      Math.round(entry.confidence * 100),
      entry.appearances,
      entry.nuclei.join(" | "),
      entry.sourceLabels.join(" | "),
    ]),
  ];
  const csv = rows.map((row) => row.map(escapeCsv).join(",")).join("\n");
  const blob = new Blob(["\uFEFF", csv], { type: "text/csv;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = filename;
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  URL.revokeObjectURL(url);
}

export default function WordArchive({
  entries,
  cycles,
  savedImpulses,
  onRecall,
  onAssemble,
  onPrune,
  onArchiveCycle,
  onRestoreCycle,
}: Props) {
  const [query, setQuery] = useState("");
  const [assemblyIds, setAssemblyIds] = useState<string[]>([]);
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [clearArmed, setClearArmed] = useState(false);
  const [cyclesOpen, setCyclesOpen] = useState(false);
  const [compareIds, setCompareIds] = useState<string[]>([]);

  const latest = entries.at(-1) ?? null;
  const kept = new Set(savedImpulses.map((impulse) => archiveKey(impulse.kind, impulse.value)));
  const totalAppearances = entries.reduce((total, entry) => total + entry.appearances, 0);
  const normalizedQuery = query.trim().toLocaleLowerCase("es");

  const filteredEntries = useMemo(() => {
    if (!normalizedQuery) return entries;
    return entries.filter((entry) =>
      [
        entry.value,
        entry.kind,
        entry.habitat,
        entry.evidence,
        entry.nucleus,
        ...entry.nuclei,
        ...entry.sourceLabels,
      ]
        .join(" ")
        .toLocaleLowerCase("es")
        .includes(normalizedQuery),
    );
  }, [entries, normalizedQuery]);

  const assembly = assemblyIds
    .map((id) => entries.find((entry) => entry.id === id))
    .filter((entry): entry is ArchivedWord => Boolean(entry));

  const selected = selectedIds
    .map((id) => entries.find((entry) => entry.id === id))
    .filter((entry): entry is ArchivedWord => Boolean(entry));

  const comparison = useMemo(() => {
    if (compareIds.length !== 2) return null;
    const left = cycles.find((cycle) => cycle.id === compareIds[0]);
    const right = cycles.find((cycle) => cycle.id === compareIds[1]);
    if (!left || !right) return null;

    const leftMap = new Map(left.entries.map((entry) => [entry.id, entry]));
    const rightMap = new Map(right.entries.map((entry) => [entry.id, entry]));
    const common = left.entries.filter((entry) => rightMap.has(entry.id));
    const onlyLeft = left.entries.filter((entry) => !rightMap.has(entry.id));
    const onlyRight = right.entries.filter((entry) => !leftMap.has(entry.id));
    const resonances = common
      .map((entry) => ({
        value: entry.value,
        delta: (rightMap.get(entry.id)?.appearances ?? 0) - entry.appearances,
        total: entry.appearances + (rightMap.get(entry.id)?.appearances ?? 0),
      }))
      .sort((a, b) => b.total - a.total)
      .slice(0, 8);

    return { left, right, common, onlyLeft, onlyRight, resonances };
  }, [compareIds, cycles]);

  useEffect(() => {
    const available = new Set(entries.map((entry) => entry.id));
    setAssemblyIds((current) => current.filter((id) => available.has(id)));
    setSelectedIds((current) => current.filter((id) => available.has(id)));
    if (!entries.length) setClearArmed(false);
  }, [entries]);

  useEffect(() => {
    const availableCycles = new Set(cycles.map((cycle) => cycle.id));
    setCompareIds((current) => current.filter((id) => availableCycles.has(id)).slice(-2));
  }, [cycles]);

  function toggleAssembly(entry: ArchivedWord) {
    setAssemblyIds((current) =>
      current.includes(entry.id)
        ? current.filter((id) => id !== entry.id)
        : [...current, entry.id].slice(-12),
    );
  }

  function toggleSelection(entry: ArchivedWord) {
    setSelectedIds((current) =>
      current.includes(entry.id)
        ? current.filter((id) => id !== entry.id)
        : [...current, entry.id],
    );
  }

  function moveAssembly(index: number, direction: -1 | 1) {
    setAssemblyIds((current) => {
      const target = index + direction;
      if (target < 0 || target >= current.length) return current;
      const next = [...current];
      [next[index], next[target]] = [next[target], next[index]];
      return next;
    });
  }

  function exportArchive() {
    downloadEntries(
      filteredEntries,
      `embrion-membrana-${new Date().toISOString().slice(0, 10)}.csv`,
    );
  }

  function archiveCurrentCycle() {
    if (!entries.length) return;
    const suggested = `Ciclo ${String(cycles.length + 1).padStart(2, "0")}`;
    const requested = window.prompt(
      "Nombre para este estrato de la Membrana:",
      suggested,
    );
    if (requested === null) return;
    const name = requested.trim() || suggested;
    onArchiveCycle(name);
    setSelectedIds([]);
    setAssemblyIds([]);
    setCyclesOpen(true);
  }

  function pruneOne(entry: ArchivedWord) {
    if (!window.confirm(`¿Podar «${entry.value}» de la Membrana actual?\n\nLos ciclos ya archivados no se modificarán.`)) return;
    onPrune([entry.id]);
  }

  function pruneSelection() {
    if (!selectedIds.length) return;
    if (!window.confirm(`¿Podar ${selectedIds.length} formas seleccionadas de la Membrana actual?`)) return;
    onPrune(selectedIds);
    setSelectedIds([]);
  }

  function clearMembrane() {
    if (!entries.length) return;
    if (!clearArmed) {
      setClearArmed(true);
      return;
    }
    onPrune(entries.map((entry) => entry.id));
    setSelectedIds([]);
    setAssemblyIds([]);
    setClearArmed(false);
  }

  function toggleCycleCompare(id: string) {
    setCompareIds((current) => {
      if (current.includes(id)) return current.filter((item) => item !== id);
      return [...current, id].slice(-2);
    });
  }

  function restoreCycle(cycle: MembraneCycle) {
    if (entries.length) {
      const accepted = window.confirm(
        `La Membrana actual contiene ${entries.length} formas.\n\n¿Sustituirla por «${cycle.name}»? Los ciclos archivados permanecerán intactos.`,
      );
      if (!accepted) return;
    }
    onRestoreCycle(cycle);
    setSelectedIds([]);
    setAssemblyIds([]);
  }

  return (
    <section className={styles.wordArchive} aria-label="Membrana de las palabras">
      <header>
        <div>
          <span>MEMBRANA DE LAS PALABRAS</span>
          <small>ARCHIVO VIVO · CADA FORMA CONSERVA NÚCLEO, EVIDENCIA Y PROCEDENCIA</small>
        </div>
        <div className={styles.archiveCounters}>
          <strong>{entries.length.toLocaleString("es-ES")}</strong><span>FORMAS</span><i />
          <strong>{totalAppearances.toLocaleString("es-ES")}</strong><span>APARICIONES</span><i />
          <strong>{cycles.length.toLocaleString("es-ES")}</strong><span>CICLOS</span>
        </div>
      </header>

      <div className={styles.archiveWorkbenchBar}>
        <label>
          <span>BUSCAR EN LA MEMBRANA</span>
          <input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="palabra, fuente, núcleo, evidencia…" />
        </label>
        <div className={styles.archiveWorkbenchActions}>
          <span><strong>{filteredEntries.length}</strong> VISIBLES</span>
          <button type="button" onClick={exportArchive} disabled={!filteredEntries.length}>EXPORTAR CSV ↗</button>
          <button type="button" className={styles.archiveCycleButton} onClick={archiveCurrentCycle} disabled={!entries.length}>ARCHIVAR CICLO ◌</button>
          <button type="button" onClick={() => setCyclesOpen((value) => !value)}>ARCHIVO · {cycles.length}</button>
          <button type="button" className={styles.archivePruneSelection} onClick={pruneSelection} disabled={!selectedIds.length}>PODAR SELECCIÓN · {selectedIds.length}</button>
          <button
            type="button"
            className={clearArmed ? styles.archiveClearArmed : styles.archiveClearButton}
            onClick={clearMembrane}
            disabled={!entries.length}
            onBlur={() => setClearArmed(false)}
          >
            {clearArmed ? "CONFIRMAR VACIADO" : "VACIAR MEMBRANA"}
          </button>
        </div>
      </div>

      {cyclesOpen ? (
        <section className={styles.cycleArchive} aria-label="Archivo de ciclos de la Membrana">
          <header>
            <div>
              <span>ARCHIVO DE CICLOS</span>
              <small>CADA ESTRATO ES UNA COPIA INMUTABLE DE LA MEMBRANA EN ESE MOMENTO</small>
            </div>
            <button type="button" onClick={() => setCyclesOpen(false)}>CERRAR ×</button>
          </header>

          {cycles.length ? (
            <div className={styles.cycleArchiveGrid}>
              {cycles.slice().reverse().map((cycle) => {
                const comparing = compareIds.includes(cycle.id);
                return (
                  <article key={cycle.id} data-comparing={comparing ? "true" : "false"}>
                    <span>{cycleDate(cycle.archivedAt)}</span>
                    <strong>{cycle.name}</strong>
                    <p>{cycle.entries.length} formas · {cycle.totalAppearances} apariciones · {cycle.sourceLabels.length} procedencias</p>
                    <div>
                      <button type="button" onClick={() => restoreCycle(cycle)}>RESTAURAR</button>
                      <button type="button" onClick={() => downloadEntries(cycle.entries, `embrion-${cycle.name.toLocaleLowerCase("es").replace(/[^a-z0-9áéíóúüñ]+/gi, "-")}.csv`)}>CSV ↗</button>
                      <button type="button" onClick={() => toggleCycleCompare(cycle.id)}>{comparing ? "EN COMPARACIÓN" : "COMPARAR"}</button>
                    </div>
                  </article>
                );
              })}
            </div>
          ) : (
            <p className={styles.cycleArchiveEmpty}>Todavía no hay ciclos fosilizados. Cuando cierres el primero, su Membrana completa quedará aquí antes de comenzar una nueva.</p>
          )}

          {comparison ? (
            <section className={styles.cycleComparison}>
              <header>
                <span>COMPARADOR DE ESTRATOS</span>
                <strong>{comparison.left.name} ↔ {comparison.right.name}</strong>
              </header>
              <div className={styles.cycleComparisonMetrics}>
                <article><span>COMUNES</span><strong>{comparison.common.length}</strong></article>
                <article><span>SOLO {comparison.left.name}</span><strong>{comparison.onlyLeft.length}</strong></article>
                <article><span>SOLO {comparison.right.name}</span><strong>{comparison.onlyRight.length}</strong></article>
                <article><span>APARICIONES</span><strong>{comparison.left.totalAppearances} ↔ {comparison.right.totalAppearances}</strong></article>
              </div>
              <div className={styles.cycleResonances}>
                <span>RESONANCIAS QUE SOBREVIVEN ENTRE CICLOS</span>
                {comparison.resonances.length ? (
                  <p>{comparison.resonances.map((item) => `${item.value}${item.delta ? ` ${item.delta > 0 ? "+" : ""}${item.delta}` : ""}`).join(" · ")}</p>
                ) : <p>No hay formas compartidas entre estos dos estratos.</p>}
              </div>
            </section>
          ) : null}
        </section>
      ) : null}

      <div className={styles.archiveThreshold}>
        <div className={styles.archiveOrgan} aria-hidden="true"><i /><i /><i /><span /></div>
        <div>
          <small>ÚLTIMA FORMA DEPOSITADA</small>
          <strong>{latest?.value ?? "La membrana espera una palabra"}</strong>
          <p>
            {latest
              ? `${latest.kind} · gravedad «${latest.nucleus}» · ${latest.appearances} ${latest.appearances === 1 ? "aparición" : "apariciones"}`
              : cycles.length
                ? "La Membrana actual está limpia. Los ciclos anteriores permanecen fosilizados en el Archivo."
                : "Escribe y elige un núcleo. El archivo se formará sin borrar nada de tu texto."}
          </p>
        </div>
        <span className={styles.archivePulse} aria-hidden="true" />
      </div>

      {filteredEntries.length ? (
        <div className={styles.archiveStrata}>
          {STRATA.map((stratum) => {
            const words = filteredEntries.filter((entry) => entry.kind === stratum.kind).slice().reverse();
            return (
              <article key={stratum.kind} data-kind={stratum.kind}>
                <header><span>{stratum.number}</span><strong>{stratum.label}</strong><small>{words.length}</small></header>
                <div>
                  {words.map((entry) => {
                    const isKept = kept.has(archiveKey(entry.kind, entry.value));
                    const isMounted = assemblyIds.includes(entry.id);
                    const isSelected = selectedIds.includes(entry.id);
                    return (
                      <div className={styles.archiveWordUnit} key={entry.id} data-selected={isSelected ? "true" : "false"}>
                        <button
                          type="button"
                          data-habitat={entry.habitat}
                          data-kept={isKept ? "true" : "false"}
                          onClick={() => onRecall(entry)}
                          title={`Recuperar «${entry.value}» · ${entry.sourceLabels.join(" · ")}`}
                        >
                          <i /><span>{entry.value}</span>{entry.appearances > 1 ? <small>×{entry.appearances}</small> : null}
                        </button>
                        <button
                          type="button"
                          className={isSelected ? styles.archiveSelectActive : styles.archiveSelectButton}
                          onClick={() => toggleSelection(entry)}
                          aria-label={isSelected ? `Deseleccionar ${entry.value}` : `Seleccionar ${entry.value} para poda`}
                          title="Seleccionar para poda"
                        >{isSelected ? "●" : "○"}</button>
                        <button
                          type="button"
                          className={isMounted ? styles.archiveMountActive : styles.archiveMountButton}
                          onClick={() => toggleAssembly(entry)}
                          aria-label={isMounted ? `Retirar ${entry.value} de la mesa` : `Añadir ${entry.value} a la mesa`}
                          title="Mesa de montaje"
                        >{isMounted ? "−" : "+"}</button>
                        <button
                          type="button"
                          className={styles.archivePruneButton}
                          onClick={() => pruneOne(entry)}
                          aria-label={`Podar ${entry.value} de la Membrana`}
                          title="Podar de la Membrana actual"
                        >×</button>
                      </div>
                    );
                  })}
                </div>
              </article>
            );
          })}
        </div>
      ) : (
        <div className={styles.archiveEmpty}><span /><p>{entries.length ? "No hay formas que coincidan con esta búsqueda." : cycles.length ? "La Membrana actual está limpia. Puedes comenzar otro ciclo o restaurar uno anterior desde el Archivo." : "Todavía no hay sedimento. La primera palabra que emita el Embrión abrirá este órgano de memoria."}</p></div>
      )}

      <section className={styles.assemblyTable} aria-label="Mesa de montaje">
        <header>
          <div><span>MESA DE MONTAJE</span><small>SELECCIONA SEDIMENTOS Y ORDENA UNA CONSTELACIÓN PROPIA</small></div>
          <strong>{assembly.length} / 12</strong>
        </header>
        {assembly.length ? (
          <div className={styles.assemblyRail}>
            {assembly.map((entry, index) => (
              <article key={entry.id}>
                <span>{String(index + 1).padStart(2, "0")}</span>
                <div><strong>{entry.value}</strong><small>{entry.kind} · {entry.evidence} · {entry.sourceLabels.slice(0, 2).join(" / ") || "sin fuente"}</small></div>
                <nav>
                  <button type="button" disabled={index === 0} onClick={() => moveAssembly(index, -1)}>←</button>
                  <button type="button" disabled={index === assembly.length - 1} onClick={() => moveAssembly(index, 1)}>→</button>
                  <button type="button" onClick={() => toggleAssembly(entry)}>×</button>
                </nav>
              </article>
            ))}
          </div>
        ) : <p className={styles.assemblyEmpty}>Pulsa ＋ junto a cualquier forma de la membrana. Aquí no se borra nada: preparas una secuencia para la Libreta de Escritura.</p>}
        <footer>
          <button type="button" disabled={!assembly.length} onClick={() => onAssemble(assembly)}>LLEVAR SECUENCIA A LA LIBRETA ↗</button>
          {assembly.length ? <button type="button" onClick={() => setAssemblyIds([])}>VACIAR MESA</button> : null}
        </footer>
      </section>

      <footer>
        <span>ARCHIVO LOCAL · LA MEMBRANA ACTUAL PUEDE PODARSE · LOS CICLOS FOSILIZADOS PERMANECEN</span>
        <strong>{savedImpulses.length} ELEGIDAS POR TI</strong>
        <small>○ SELECCIONAR · ＋ MONTAR · × PODAR</small>
      </footer>
    </section>
  );
}
