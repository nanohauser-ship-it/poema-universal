const COMPOSITOR_WIDTH = 384;
const COMPOSITOR_HEIGHT = 580;
const FRAME_INTERVAL = 1 / 24;

export class HumanCompositor {
  readonly canvas: HTMLCanvasElement;

  private readonly sourceCanvas: HTMLCanvasElement;
  private readonly maskCanvas: HTMLCanvasElement;
  private readonly outputContext: CanvasRenderingContext2D | null;
  private readonly sourceContext: CanvasRenderingContext2D | null;
  private readonly maskContext: CanvasRenderingContext2D | null;
  private readonly maskImage: ImageData | null;

  private video: HTMLVideoElement | null = null;
  private backgroundPixels: Uint8ClampedArray | null = null;
  private calibrationTimer: number | null = null;
  private calibrationResolve: ((success: boolean) => void) | null = null;
  private frameAccumulator = 0;
  private disposed = false;

  constructor() {
    this.canvas = this.createCanvas();
    this.sourceCanvas = this.createCanvas();
    this.maskCanvas = this.createCanvas();

    this.outputContext = this.canvas.getContext("2d");
    this.sourceContext = this.sourceCanvas.getContext("2d", {
      willReadFrequently: true,
    });
    this.maskContext = this.maskCanvas.getContext("2d");
    this.maskImage = this.maskContext?.createImageData(
      COMPOSITOR_WIDTH,
      COMPOSITOR_HEIGHT
    ) ?? null;
  }

  connect(video: HTMLVideoElement): HTMLCanvasElement {
    if (this.disposed) {
      return this.canvas;
    }

    this.cancelCalibration();
    this.video = video;
    this.backgroundPixels = null;
    this.frameAccumulator = FRAME_INTERVAL;
    this.renderFrame();
    return this.canvas;
  }

  disconnect(): void {
    this.cancelCalibration();
    this.video = null;
    this.backgroundPixels = null;
    this.frameAccumulator = 0;
    this.clearCanvases();
  }

  update(deltaTime: number): boolean {
    if (this.disposed || !this.video) {
      return false;
    }

    this.frameAccumulator += deltaTime;

    if (this.frameAccumulator < FRAME_INTERVAL) {
      return false;
    }

    this.frameAccumulator %= FRAME_INTERVAL;
    return this.renderFrame();
  }

  calibrateBackground(delayMs = 3000): Promise<boolean> {
    if (this.disposed || !this.video || !this.sourceContext) {
      return Promise.resolve(false);
    }

    this.cancelCalibration();

    return new Promise((resolve) => {
      this.calibrationResolve = resolve;
      this.calibrationTimer = window.setTimeout(() => {
        this.calibrationTimer = null;
        this.calibrationResolve = null;

        if (this.disposed || !this.video || !this.drawSourceFrame()) {
          resolve(false);
          return;
        }

        const frame = this.sourceContext?.getImageData(
          0,
          0,
          COMPOSITOR_WIDTH,
          COMPOSITOR_HEIGHT
        );

        if (!frame) {
          resolve(false);
          return;
        }

        this.backgroundPixels = new Uint8ClampedArray(frame.data);
        this.renderCutout(frame);
        resolve(true);
      }, delayMs);
    });
  }

  disableCutout(): void {
    this.cancelCalibration();
    this.backgroundPixels = null;
    this.renderFrame();
  }

  dispose(): void {
    if (this.disposed) {
      return;
    }

    this.disposed = true;
    this.disconnect();
  }

  private renderFrame(): boolean {
    if (!this.drawSourceFrame()) {
      return false;
    }

    if (!this.backgroundPixels || !this.sourceContext) {
      this.renderRawFrame();
      return true;
    }

    const frame = this.sourceContext.getImageData(
      0,
      0,
      COMPOSITOR_WIDTH,
      COMPOSITOR_HEIGHT
    );
    this.renderCutout(frame);
    return true;
  }

  private drawSourceFrame(): boolean {
    const video = this.video;
    const context = this.sourceContext;

    if (
      !video ||
      !context ||
      video.readyState < HTMLMediaElement.HAVE_CURRENT_DATA ||
      video.videoWidth <= 0 ||
      video.videoHeight <= 0
    ) {
      return false;
    }

    const targetAspect = COMPOSITOR_WIDTH / COMPOSITOR_HEIGHT;
    const sourceAspect = video.videoWidth / video.videoHeight;
    let sourceX = 0;
    let sourceY = 0;
    let sourceWidth = video.videoWidth;
    let sourceHeight = video.videoHeight;

    if (sourceAspect > targetAspect) {
      sourceWidth = video.videoHeight * targetAspect;
      sourceX = (video.videoWidth - sourceWidth) / 2;
    } else {
      sourceHeight = video.videoWidth / targetAspect;
      sourceY = (video.videoHeight - sourceHeight) / 2;
    }

    context.save();
    context.clearRect(0, 0, COMPOSITOR_WIDTH, COMPOSITOR_HEIGHT);
    context.setTransform(-1, 0, 0, 1, COMPOSITOR_WIDTH, 0);
    context.drawImage(
      video,
      sourceX,
      sourceY,
      sourceWidth,
      sourceHeight,
      0,
      0,
      COMPOSITOR_WIDTH,
      COMPOSITOR_HEIGHT
    );
    context.restore();
    return true;
  }

  private renderRawFrame(): void {
    const context = this.outputContext;

    if (!context) {
      return;
    }

    context.clearRect(0, 0, COMPOSITOR_WIDTH, COMPOSITOR_HEIGHT);
    context.drawImage(this.sourceCanvas, 0, 0);
  }

  private renderCutout(frame: ImageData): void {
    const background = this.backgroundPixels;
    const maskImage = this.maskImage;
    const maskContext = this.maskContext;
    const outputContext = this.outputContext;

    if (!background || !maskImage || !maskContext || !outputContext) {
      this.renderRawFrame();
      return;
    }

    const pixels = frame.data;
    const mask = maskImage.data;
    const lowerThreshold = 18;
    const upperThreshold = 58;
    const thresholdRange = upperThreshold - lowerThreshold;

    for (let index = 0; index < pixels.length; index += 4) {
      const redDifference = Math.abs(pixels[index] - background[index]);
      const greenDifference = Math.abs(
        pixels[index + 1] - background[index + 1]
      );
      const blueDifference = Math.abs(
        pixels[index + 2] - background[index + 2]
      );
      const maximumDifference = Math.max(
        redDifference,
        greenDifference,
        blueDifference
      );
      const averageDifference =
        (redDifference + greenDifference + blueDifference) / 3;
      const distance = maximumDifference * 0.68 + averageDifference * 0.32;
      const normalized = Math.min(
        1,
        Math.max(0, (distance - lowerThreshold) / thresholdRange)
      );
      const eased = normalized * normalized * (3 - 2 * normalized);
      const alpha = Math.round(eased * 255);

      mask[index] = 255;
      mask[index + 1] = 255;
      mask[index + 2] = 255;
      mask[index + 3] = alpha;

      if (alpha < 8) {
        background[index] = background[index] * 0.985 + pixels[index] * 0.015;
        background[index + 1] =
          background[index + 1] * 0.985 + pixels[index + 1] * 0.015;
        background[index + 2] =
          background[index + 2] * 0.985 + pixels[index + 2] * 0.015;
      }
    }

    maskContext.putImageData(maskImage, 0, 0);
    outputContext.save();
    outputContext.clearRect(0, 0, COMPOSITOR_WIDTH, COMPOSITOR_HEIGHT);
    outputContext.drawImage(this.sourceCanvas, 0, 0);
    outputContext.globalCompositeOperation = "destination-in";
    outputContext.filter = "blur(1.2px)";
    outputContext.drawImage(this.maskCanvas, 0, 0);
    outputContext.restore();
  }

  private cancelCalibration(): void {
    if (this.calibrationTimer !== null) {
      window.clearTimeout(this.calibrationTimer);
      this.calibrationTimer = null;
    }

    this.calibrationResolve?.(false);
    this.calibrationResolve = null;
  }

  private clearCanvases(): void {
    this.outputContext?.clearRect(0, 0, COMPOSITOR_WIDTH, COMPOSITOR_HEIGHT);
    this.sourceContext?.clearRect(0, 0, COMPOSITOR_WIDTH, COMPOSITOR_HEIGHT);
    this.maskContext?.clearRect(0, 0, COMPOSITOR_WIDTH, COMPOSITOR_HEIGHT);
  }

  private createCanvas(): HTMLCanvasElement {
    const canvas = document.createElement("canvas");
    canvas.width = COMPOSITOR_WIDTH;
    canvas.height = COMPOSITOR_HEIGHT;
    return canvas;
  }
}
