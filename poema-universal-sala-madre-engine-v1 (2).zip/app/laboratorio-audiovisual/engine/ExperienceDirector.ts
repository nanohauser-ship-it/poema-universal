import { CameraDirector } from "./CameraDirector";
import { SurfaceManager } from "./SurfaceManager";
import type {
  ArchitectureConfiguration,
  DepthLayerId,
  EnvironmentConfiguration,
  ExperienceDefinition,
  MasterFrame,
  SurfaceConfiguration,
} from "../types/audiovisual";

export interface ExperienceRuntime {
  applyEnvironment(configuration: EnvironmentConfiguration): void;
  applyArchitecture(configuration: ArchitectureConfiguration): void;
  setLayerVisibility(layer: DepthLayerId, visible: boolean): void;
  updateArchitecture(frame: MasterFrame): void;
}

export class ExperienceDirector {
  private activeExperience: ExperienceDefinition | null = null;
  private readonly masterFrame: MasterFrame = {
    elapsedTime: 0,
    deltaTime: 0,
  };

  constructor(
    private readonly experiences: Readonly<Record<string, ExperienceDefinition>>,
    private readonly surfaces: SurfaceManager,
    private readonly camera: CameraDirector,
    private readonly runtime: ExperienceRuntime
  ) {}

  setExperience(id: string): void {
    const experience = this.experiences[id];

    if (!experience) {
      return;
    }

    this.activeExperience = experience;
    this.runtime.applyEnvironment(experience.environment);
    this.runtime.applyArchitecture(experience.architectureState);
    this.camera.setCamera(experience.camera);
    this.surfaces.configureMany(experience.surfaces);

    const humanConfiguration: SurfaceConfiguration = {
      id: "HUMAN_LAYER",
      content: experience.human.content,
      position: experience.human.position,
      rotation: experience.human.rotation,
      scale: experience.human.scale,
      visible: experience.human.visible,
      opacity: experience.human.opacity,
    };

    this.surfaces.configure(humanConfiguration);

    const layers: readonly DepthLayerId[] = [
      "BACKGROUND_FX",
      "HUMAN_LAYER",
      "FOREGROUND_FX",
    ];

    for (const layer of layers) {
      const state = experience.layers[layer];

      if (state) {
        this.runtime.setLayerVisibility(layer, state.visible);
      }
    }
  }

  update(elapsedTime: number, deltaTime: number): void {
    this.masterFrame.elapsedTime = elapsedTime;
    this.masterFrame.deltaTime = deltaTime;
    this.surfaces.update(deltaTime);
    this.camera.update(deltaTime);
    this.runtime.updateArchitecture(this.masterFrame);
  }

  getActiveExperience(): ExperienceDefinition | null {
    return this.activeExperience;
  }
}
