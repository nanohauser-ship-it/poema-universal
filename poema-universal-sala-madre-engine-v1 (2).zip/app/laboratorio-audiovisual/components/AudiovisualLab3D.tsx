"use client";

import { useEffect, useRef, useState } from "react";

import { SceneEngine } from "../engine/SceneEngine";
import type { SceneMode } from "../types/audiovisual";
import { LabControls } from "./LabControls";

export default function AudiovisualLab3D() {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const engineRef = useRef<SceneEngine | null>(null);
  const [mode, setMode] = useState<SceneMode>("gallery");

  useEffect(() => {
    const mount = containerRef.current;

    if (!mount) {
      return;
    }

    const engine = new SceneEngine(mount);
    engineRef.current = engine;
    engine.start("gallery");

    return () => {
      engine.dispose();

      if (engineRef.current === engine) {
        engineRef.current = null;
      }
    };
  }, []);

  const changeMode = (nextMode: SceneMode): void => {
    setMode(nextMode);
    engineRef.current?.setExperience(nextMode);
  };

  return (
    <section className="relative h-screen min-h-[720px] overflow-hidden bg-black text-white">
      <div ref={containerRef} className="absolute inset-0" />

      <header className="pointer-events-none absolute inset-x-0 top-0 z-20 flex items-start justify-between p-6 sm:p-8">
        <div>
          <p className="text-[8px] uppercase tracking-[0.46em] text-[#d4ad6d]">
            Poema Universal
          </p>
          <h1 className="mt-3 font-serif text-3xl tracking-[-0.04em] sm:text-5xl">
            Sala Madre
          </h1>
          <p className="mt-3 text-[8px] uppercase tracking-[0.26em] text-white/30">
            Arquitectura audiovisual
          </p>
        </div>

        <p className="text-[7px] uppercase tracking-[0.24em] text-white/30">
          Arrastra para mirar
        </p>
      </header>

      <LabControls mode={mode} onModeChange={changeMode} />
    </section>
  );
}

