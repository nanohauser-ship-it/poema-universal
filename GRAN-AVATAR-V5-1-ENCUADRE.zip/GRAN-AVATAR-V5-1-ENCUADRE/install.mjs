import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";
const scriptDirectory = path.dirname(fileURLToPath(import.meta.url));
const payloadDirectory = path.join(scriptDirectory, "payload");
const targetDirectory = path.resolve(process.argv[2] ?? path.join(os.homedir(), "poema-universal"));
function fail(message){ console.error(`\n✗ ${message}\n`); process.exit(1); }
function listFiles(directory,prefix=""){ return fs.readdirSync(directory,{withFileTypes:true}).flatMap((entry)=>{ const rel=path.join(prefix,entry.name); const abs=path.join(directory,entry.name); return entry.isDirectory()?listFiles(abs,rel):[rel]; }).sort(); }
if(!fs.existsSync(path.join(targetDirectory,"package.json"))||!fs.existsSync(path.join(targetDirectory,"app/poema-universal/gran-avatar"))) fail(`La carpeta no parece ser Poema Universal: ${targetDirectory}`);
const timestamp=new Date().toISOString().replace(/[-:]/g,"").replace(/\.\d{3}Z$/,"Z");
const backupDirectory=path.join(targetDirectory,"backups",`gran-avatar-v5-1-encuadre-${timestamp}`);
const files=listFiles(payloadDirectory); fs.mkdirSync(backupDirectory,{recursive:true});
for(const rel of files){ const dst=path.join(targetDirectory,rel); if(fs.existsSync(dst)&&fs.statSync(dst).isFile()){ const b=path.join(backupDirectory,rel); fs.mkdirSync(path.dirname(b),{recursive:true}); fs.copyFileSync(dst,b); } }
for(const rel of files){ const src=path.join(payloadDirectory,rel), dst=path.join(targetDirectory,rel); fs.mkdirSync(path.dirname(dst),{recursive:true}); fs.copyFileSync(src,dst); }
console.log("\n===== EL GRAN AVATAR · V5.1 ENCUADRE SEGURO =====");
console.log(`Proyecto: ${targetDirectory}`);
console.log(`Archivos integrados: ${files.length}`);
console.log(`Copia de seguridad: ${backupDirectory}`);
console.log("✓ Vídeo maestro en object-fit: contain");
console.log("✓ Cabeza completa protegida en todos los planos");
console.log("✓ Zoom íntimo reducido y transiciones conservadas");
console.log("✓ No se toca voz, estados, Supabase, .env.local ni package.json");
console.log("\nReinicia con: npm run dev -- --webpack -p 3000\n");
