#!/usr/bin/env bash
set -euo pipefail

PROJECT="$HOME/poema-universal"
SOURCE_DIR="$(cd "$(dirname "$0")" && pwd)"
SOURCE_IMAGE="$SOURCE_DIR/libro-alquimico-portada.png"
PUBLIC_DIR="$PROJECT/public/poema-universal/bestiario/libro-alquimico"
TARGET_IMAGE="$PUBLIC_DIR/portada-libro-alquimico.png"
CSS_FILE="$PROJECT/app/poema-universal/bestiario-poetico/libro-alquimico/libro-alquimico.module.css"
STAMP="$(date +%Y%m%d-%H%M%S)"
MARKER="LIBRO ALQUIMICO · PORTADA EDITORIAL ROJA"

[[ -d "$PROJECT" ]] || { echo "ERROR: no existe $PROJECT"; exit 1; }
[[ -f "$SOURCE_IMAGE" ]] || { echo "ERROR: no existe $SOURCE_IMAGE"; exit 1; }
[[ -f "$CSS_FILE" ]] || { echo "ERROR: no existe $CSS_FILE"; exit 1; }

mkdir -p "$PUBLIC_DIR"
cp "$SOURCE_IMAGE" "$TARGET_IMAGE"
cp "$CSS_FILE" "$CSS_FILE.$STAMP.bak"

if ! grep -q "$MARKER" "$CSS_FILE"; then
cat >> "$CSS_FILE" <<'CSS'

/* LIBRO ALQUIMICO · PORTADA EDITORIAL ROJA */
.bookCover {
  aspect-ratio: 3 / 4;
  width: min(100%, 32rem);
  padding: 0;
  overflow: hidden;
  border: 1px solid rgba(187, 28, 24, 0.5);
  background-image:
    linear-gradient(
      180deg,
      rgba(0, 0, 0, 0.02),
      rgba(0, 0, 0, 0.08)
    ),
    url("/poema-universal/bestiario/libro-alquimico/portada-libro-alquimico.png");
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
  box-shadow:
    -1.4rem 2.8rem 5.5rem rgba(0, 0, 0, 0.82),
    0 0 3rem rgba(157, 20, 18, 0.12),
    inset 0 0 0 1px rgba(222, 62, 48, 0.14);
}

.bookCover::before {
  display: none;
}

.coverInnerBorder {
  opacity: 0;
  pointer-events: none;
}

.coverAura {
  background:
    radial-gradient(
      circle,
      rgba(179, 24, 21, 0.18),
      transparent 67%
    );
}

@media (max-width: 900px) {
  .bookCover {
    width: min(100%, 29rem);
  }
}
CSS
fi

echo ""
echo "✓ Portada copiada en: $TARGET_IMAGE"
echo "✓ Estilos aplicados"
echo "✓ Copia de seguridad: $CSS_FILE.$STAMP.bak"
echo ""
echo "Abre:"
echo "http://localhost:3000/poema-universal/bestiario-poetico/libro-alquimico"
